#!/usr/bin/env python3
import os
import sys
import time
import json
import logging
import asyncio
import hashlib
import difflib
import uuid
import signal
from typing import Dict, List, Optional, Any, Set, Tuple
from datetime import datetime
from pathlib import Path
import threading

import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Depends, HTTPException, Request, Response
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, FileSystemEvent

# Import our modules
from persistence import PersistenceManager
from analytics import FileAnalytics
from notifications import NotificationManager
from security import SecurityManager, api_key_header
from optimizations import FileIndexer, MemoryOptimizer, ConnectionManager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("server.log")
    ]
)
logger = logging.getLogger("file-monitor-mcp")

# Constants
SERVER_NAME = "File Monitor MCP"
VERSION = "1.0.0"
DEFAULT_CONFIG = {
    "watch_path": ".",
    "file_patterns": [],
    "max_file_size": 1024 * 1024,  # 1MB
    "db_path": "file_monitor.db",
    "api_key": os.environ.get("MCP_API_KEY", "dev-api-key-change-me-in-production")
}

# Models
class AuthRequest(BaseModel):
    api_key: str

class ConfigRequest(BaseModel):
    watch_path: Optional[str] = None
    file_patterns: Optional[List[str]] = None
    max_file_size: Optional[int] = None

class NotificationConfigRequest(BaseModel):
    email: Optional[Dict[str, Any]] = None
    webhook_url: Optional[str] = None
    rule: Optional[Dict[str, Any]] = None

class FileConversation:
    """Represents a conversation about a file"""
    def __init__(self, file_path: str):
        self.file_path = file_path
        self.messages: List[Dict[str, Any]] = []
        self.content: Optional[str] = None
        self.previous_content: Optional[str] = None
        self.content_hash: Optional[str] = None
        self.last_modified: float = 0
        
        # Initialize with current content
        self.update_content()
    
    def update_content(self) -> bool:
        """Update content from file, return True if changed"""
        try:
            if not os.path.exists(self.file_path):
                return False
            
            # Get file stats
            stat = os.stat(self.file_path)
            self.last_modified = stat.st_mtime
            
            # Read file content
            with open(self.file_path, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()
            
            # Calculate hash
            content_hash = hashlib.md5(content.encode()).hexdigest()
            
            # Check if content changed
            if content_hash != self.content_hash:
                # Store previous content
                self.previous_content = self.content
                
                # Update content
                self.content = content
                self.content_hash = content_hash
                return True
            
            return False
        except Exception as e:
            logger.error(f"Error updating content for {self.file_path}: {e}")
            return False
    
    def add_message(self, role: str, content: str) -> Dict[str, Any]:
        """Add a message to the conversation"""
        message = {
            "role": role,
            "content": content,
            "timestamp": time.time(),
            "id": str(uuid.uuid4())
        }
        
        self.messages.append(message)
        return message
    
    def generate_diff(self) -> Optional[str]:
        """Generate diff between current and previous content"""
        if not self.previous_content or not self.content:
            return None
        
        # Generate diff
        diff = difflib.unified_diff(
            self.previous_content.splitlines(keepends=True),
            self.content.splitlines(keepends=True),
            fromfile="previous",
            tofile="current"
        )
        
        return ''.join(diff)

class FileMonitorState:
    """State for the file monitor"""
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.conversations: Dict[str, FileConversation] = {}
        self.persistence = PersistenceManager(config["db_path"])
        self.analytics = FileAnalytics(self.persistence)
        self.notifications = NotificationManager()
        self.security = SecurityManager(config["api_key"])
        self.file_indexer = FileIndexer()
        self.memory_optimizer = MemoryOptimizer()
        self.connection_manager = ConnectionManager()
        self.start_time = time.time()
        
        # Load conversations from persistence
        self._load_conversations()
    
    def _load_conversations(self) -> None:
        """Load conversations from persistence"""
        try:
            # Get all files
            files = self.persistence.get_all_files()
            
            for file in files:
                file_path = file["path"]
                
                # Skip files that don't exist anymore
                if not os.path.exists(file_path):
                    continue
                
                # Create conversation
                conversation = FileConversation(file_path)
                
                # Load messages
                messages = self.persistence.get_messages(file_path)
                conversation.messages = messages
                
                # Add to conversations
                self.conversations[file_path] = conversation
            
            logger.info(f"Loaded {len(self.conversations)} conversations from persistence")
        except Exception as e:
            logger.error(f"Error loading conversations: {e}")
    
    def get_conversation(self, file_path: str) -> FileConversation:
        """Get or create a conversation for a file"""
        if file_path not in self.conversations:
            # Create new conversation
            conversation = FileConversation(file_path)
            self.conversations[file_path] = conversation
            
            # Add system message
            message = conversation.add_message("system", f"File created: {file_path}")
            self.persistence.save_message(file_path, message)
            
            # Save file content
            self.persistence.save_file_content(file_path, conversation.content, conversation.content_hash)
            
            # Track event
            self.analytics.track_event("created", file_path)
        
        return self.conversations[file_path]
    
    def update_file(self, file_path: str, event_type: str) -> Tuple[bool, Optional[Dict[str, Any]]]:
        """Update a file and return if content changed and the message"""
        try:
            # Get conversation
            conversation = self.get_conversation(file_path)
            
            # Update content
            content_changed = conversation.update_content()
            
            # Generate diff
            diff = conversation.generate_diff() if content_changed else None
            
            # Add message
            message = None
            if content_changed:
                message_content = f"File {event_type}: {file_path}"
                if diff:
                    message_content += f"\n\n```diff\n{diff}\n```"
                
                message = conversation.add_message("system", message_content)
                self.persistence.save_message(file_path, message)
                
                # Save file content
                self.persistence.save_file_content(file_path, conversation.content, conversation.content_hash)
            
            # Track event
            self.analytics.track_event(event_type, file_path, {"content_changed": content_changed})
            
            # Send notification
            if content_changed:
                self.notifications.send_notification(event_type, {
                    "file_path": file_path,
                    "content_changed": content_changed,
                    "diff": diff,
                    "message": message
                })
            
            # Optimize memory if needed
            self.memory_optimizer.optimize_memory(self)
            
            return content_changed, message
        except Exception as e:
            logger.error(f"Error updating file {file_path}: {e}")
            return False, None
    
    def delete_file(self, file_path: str) -> None:
        """Handle file deletion"""
        try:
            # Get conversation
            if file_path in self.conversations:
                conversation = self.conversations[file_path]
                
                # Add message
                message = conversation.add_message("system", f"File deleted: {file_path}")
                self.persistence.save_message(file_path, message)
                
                # Track event
                self.analytics.track_event("deleted", file_path)
                
                # Send notification
                self.notifications.send_notification("deleted", {
                    "file_path": file_path,
                    "message": message
                })
        except Exception as e:
            logger.error(f"Error handling file deletion {file_path}: {e}")
    
    def get_server_stats(self) -> Dict[str, Any]:
        """Get server statistics"""
        return {
            "uptime": time.time() - self.start_time,
            "file_count": len(self.conversations),
            "client_count": len(self.connection_manager.active_connections),
            "watch_path": self.config["watch_path"],
            "file_patterns": self.config["file_patterns"],
            "max_file_size": self.config["max_file_size"]
        }

class FileEventHandler(FileSystemEventHandler):
    """Handler for file system events"""
    def __init__(self, state: FileMonitorState):
        self.state = state
    
    def on_modified(self, event: FileSystemEvent) -> None:
        """Handle file modification"""
        if event.is_directory:
            return
        
        file_path = event.src_path
        
        # Check if file matches patterns
        if not self._should_process_file(file_path):
            return
        
        # Update file
        content_changed, message = self.state.update_file(file_path, "modified")
        
        # Send event to clients
        if content_changed:
            asyncio.run_coroutine_threadsafe(
                self._send_event_to_clients(file_path, "modified", message),
                asyncio.get_event_loop()
            )
    
    def on_created(self, event: FileSystemEvent) -> None:
        """Handle file creation"""
        if event.is_directory:
            return
        
        file_path = event.src_path
        
        # Check if file matches patterns
        if not self._should_process_file(file_path):
            return
        
        # Update file
        content_changed, message = self.state.update_file(file_path, "created")
        
        # Send event to clients
        asyncio.run_coroutine_threadsafe(
            self._send_event_to_clients(file_path, "created", message),
            asyncio.get_event_loop()
        )
    
    def on_deleted(self, event: FileSystemEvent) -> None:
        """Handle file deletion"""
        if event.is_directory:
            return
        
        file_path = event.src_path
        
        # Check if file matches patterns
        if not self._should_process_file(file_path):
            return
        
        # Handle deletion
        self.state.delete_file(file_path)
        
        # Send event to clients
        asyncio.run_coroutine_threadsafe(
            self._send_event_to_clients(file_path, "deleted", None),
            asyncio.get_event_loop()
        )
    
    def on_moved(self, event: FileSystemEvent) -> None:
        """Handle file move/rename"""
        if event.is_directory:
            return
        
        src_path = event.src_path
        dest_path = event.dest_path
        
        # Check if file matches patterns
        if not self._should_process_file(src_path) and not self._should_process_file(dest_path):
            return
        
        # Handle as delete + create
        self.state.delete_file(src_path)
        content_changed, message = self.state.update_file(dest_path, "created")
        
        # Send events to clients
        asyncio.run_coroutine_threadsafe(
            self._send_event_to_clients(src_path, "deleted", None),
            asyncio.get_event_loop()
        )
        
        asyncio.run_coroutine_threadsafe(
            self._send_event_to_clients(dest_path, "created", message),
            asyncio.get_event_loop()
        )
    
    def _should_process_file(self, file_path: str) -> bool:
        """Check if a file should be processed"""
        # Check if file exists
        if not os.path.exists(file_path):
            return True  # For deletion events
        
        # Check if file is too large
        try:
            if os.path.getsize(file_path) > self.state.config["max_file_size"]:
                return False
        except OSError:
            return False
        
        # Check if file matches patterns
        if self.state.config["file_patterns"]:
            import fnmatch
            filename = os.path.basename(file_path)
            
            for pattern in self.state.config["file_patterns"]:
                if fnmatch.fnmatch(filename, pattern):
                    return True
            
            return False
        
        return True
    
    async def _send_event_to_clients(self, file_path: str, event_type: str, message: Optional[Dict[str, Any]]) -> None:
        """Send event to connected clients"""
        # Create event
        event = {
            "file_path": file_path,
            "event_type": event_type,
            "timestamp": time.time(),
            "content_changed": message is not None
        }
        
        # Add message if available
        if message:
            event["message"] = message
        
        # Add diff if available
        if message and "```diff" in message["content"]:
            # Extract diff from message
            parts = message["content"].split("```diff")
            if len(parts) > 1:
                diff_part = parts[1].split("```")[0]
                event["diff"] = diff_part
        
        # Send to clients
        await self.state.connection_manager.send_to_all(event)

# Initialize FastAPI app
app = FastAPI(title=SERVER_NAME, version=VERSION)

# Load configuration
def load_config() -> Dict[str, Any]:
    """Load configuration from file or environment"""
    config = DEFAULT_CONFIG.copy()
    
    # Check for config file
    config_file = os.environ.get("CONFIG_FILE", os.path.expanduser("~/.file-monitor-mcp/config.json"))
    
    if os.path.exists(config_file):
        try:
            with open(config_file, 'r') as f:
                file_config = json.load(f)
                config.update(file_config)
        except Exception as e:
            logger.error(f"Error loading config file: {e}")
    
    # Override with environment variables
    if "WATCH_PATH" in os.environ:
        config["watch_path"] = os.environ["WATCH_PATH"]
    
    if "FILE_PATTERNS" in os.environ:
        patterns = os.environ["FILE_PATTERNS"].split(",")
        config["file_patterns"] = [p.strip() for p in patterns if p.strip()]
    
    if "MAX_FILE_SIZE" in os.environ:
        try:
            config["max_file_size"] = int(os.environ["MAX_FILE_SIZE"])
        except ValueError:
            pass
    
    if "MCP_API_KEY" in os.environ:
        config["api_key"] = os.environ["MCP_API_KEY"]
    
    if "DB_PATH" in os.environ:
        config["db_path"] = os.environ["DB_PATH"]
    
    return config

# Initialize state
state = FileMonitorState(load_config())

# Set up file system observer
observer = Observer()
event_handler = FileEventHandler(state)
observer.schedule(event_handler, state.config["watch_path"], recursive=True)

# Set up templates and static files
templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")

# Shutdown handler
def shutdown_handler(signum, frame):
    """Handle shutdown signal"""
    logger.info("Shutting down...")
    
    # Stop observer
    observer.stop()
    observer.join()
    
    # Stop notifications
    state.notifications.stop()
    
    # Exit
    sys.exit(0)

# Register shutdown handler
signal.signal(signal.SIGINT, shutdown_handler)
signal.signal(signal.SIGTERM, shutdown_handler)

# Routes
@app.get("/", response_class=HTMLResponse)
async def get_index(request: Request):
    """Serve the index page"""
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "server_name": SERVER_NAME,
            "version": VERSION
        }
    )

@app.post("/auth")
async def authenticate(auth_request: AuthRequest):
    """Authenticate and get token"""
    if state.security.verify_api_key(auth_request.api_key):
        token, expires = state.security.create_token({"sub": "user"})
        return {
            "token": token,
            "expires": expires.isoformat()
        }
    
    raise HTTPException(status_code=401, detail="Invalid API key")

@app.post("/config")
async def update_config(config_request: ConfigRequest, api_key: str = Depends(api_key_header)):
    """Update server configuration"""
    # Verify API key
    if not state.security.verify_api_key(api_key):
        raise HTTPException(status_code=401, detail="Invalid API key")
    
    # Update config
    if config_request.watch_path is not None:
        state.config["watch_path"] = config_request.watch_path
        
        # Update observer
        observer.unschedule_all()
        observer.schedule(event_handler, state.config["watch_path"], recursive=True)
    
    if config_request.file_patterns is not None:
        state.config["file_patterns"] = config_request.file_patterns
    
    if config_request.max_file_size is not None:
        state.config["max_file_size"] = config_request.max_file_size
    
    # Save config to file
    config_file = os.environ.get("CONFIG_FILE", os.path.expanduser("~/.file-monitor-mcp/config.json"))
    os.makedirs(os.path.dirname(config_file), exist_ok=True)
    
    with open(config_file, 'w') as f:
        json.dump(state.config, f, indent=2)
    
    return {"config": state.config}

@app.post("/notifications/config")
async def update_notification_config(config_request: NotificationConfigRequest, api_key: str = Depends(api_key_header)):
    """Update notification configuration"""
    # Verify API key
    if not state.security.verify_api_key(api_key):
        raise HTTPException(status_code=401, detail="Invalid API key")
    
    # Update config
    if config_request.email is not None:
        state.notifications.configure_email(config_request.email)
    
    if config_request.webhook_url is not None:
        state.notifications.configure_webhook(config_request.webhook_url)
    
    if config_request.rule is not None:
        state.notifications.clear_rules()
        state.notifications.add_rule(config_request.rule)
    
    return {"success": True}

@app.get("/api/files")
async def get_files(api_key: str = Depends(api_key_header)):
    """Get all files"""
    # Verify API key
    if not state.security.verify_api_key(api_key):
        raise HTTPException(status_code=401, detail="Invalid API key")
    
    # Get files
    files = state.persistence.get_all_files()
    
    return {"files": files}

@app.websocket("/mcp")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for real-time updates"""
    await websocket.accept()
    
    try:
        # Wait for authentication
        auth_message = await websocket.receive_json()
        
        if "token" not in auth_message:
            await websocket.send_json({"error": "Authentication required"})
            await websocket.close()
            return
        
        # Verify token
        token_data = state.security.verify_token(auth_message["token"])
        
        if not token_data:
            await websocket.send_json({"error": "Invalid or expired token"})
            await websocket.close()
            return
        
        # Add connection
        state.connection_manager.add_connection(websocket, {"client_id": token_data.get("sub", "unknown")})
        
        # Send init response
        await websocket.send_json({
            "type": "init_response",
            "name": SERVER_NAME,
            "version": VERSION,
            "capabilities": ["file_monitoring", "analytics", "notifications"]
        })
        
        # Handle messages
        while True:
            message = await websocket.receive_json()
            
            # Handle query
            if message.get("type") == "query":
                await handle_query(websocket, message)
            
            # Handle ping
            elif message.get("type") == "ping":
                await websocket.send_json({
                    "type": "pong",
                    "id": message.get("id"),
                    "server_time": time.time()
                })
    
    except WebSocketDisconnect:
        # Remove connection
        state.connection_manager.remove_connection(websocket)
    
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        
        # Remove connection
        state.connection_manager.remove_connection(websocket)

async def handle_query(websocket: WebSocket, message: Dict[str, Any]):
    """Handle a query from a client"""
    query_id = message.get("id")
    query = message.get("query", {})
    query_type = query.get("query_type")
    
    response = {"error": "Invalid query"}
    
    try:
        # Get all files
        if query_type == "get_all_files":
            filters = query.get("filters", {})
            files = state.persistence.get_all_files()
            
            # Apply filters
            if filters:
                filtered_files = []
                
                for file in files:
                    match = True
                    
                    for key, value in filters.items():
                        if key in file and file[key] != value:
                            match = False
                            break
                    
                    if match:
                        filtered_files.append(file)
                
                files = filtered_files
            
            response = {"files": files}
        
        # Get file history
        elif query_type == "get_file_history":
            file_path = query.get("file_path")
            filters = query.get("filters", {})
            
            if not file_path:
                response = {"error": "File path required"}
            else:
                # Get conversation
                conversation = state.get_conversation(file_path)
                
                # Get messages
                messages = conversation.messages
                
                # Apply filters
                if filters:
                    if "limit" in filters:
                        messages = messages[-filters["limit"]:]
                
                response = {
                    "file_path": file_path,
                    "messages": messages,
                    "content": conversation.content,
                    "last_modified": conversation.last_modified,
                    "message_count": len(conversation.messages),
                    "diff": conversation.generate_diff() or "No diff available"
                }
        
        # Get file diff
        elif query_type == "get_file_diff":
            file_path = query.get("file_path")
            
            if not file_path:
                response = {"error": "File path required"}
            else:
                # Get conversation
                conversation = state.get_conversation(file_path)
                
                # Get diff
                diff = conversation.generate_diff()
                
                response = {
                    "file_path": file_path,
                    "diff": diff or "No diff available"
                }
        
        # Get recent changes
        elif query_type == "get_recent_changes":
            details = query.get("details", {})
            filters = query.get("filters", {})
            
            limit = details.get("limit", 10)
            
            # Get all files
            files = state.persistence.get_all_files()
            
            # Sort by last modified
            files.sort(key=lambda x: x["last_modified"], reverse=True)
            
            # Limit
            files = files[:limit]
            
            # Get most recent message for each file
            recent_changes = {}
            
            for file in files:
                file_path = file["path"]
                
                # Get messages
                messages = state.persistence.get_messages(file_path, limit=1)
                
                if messages:
                    recent_changes[file_path] = messages[0]
            
            response = {"recent_changes": recent_changes}
        
        # Get server stats
        elif query_type == "get_server_stats":
            response = state.get_server_stats()
        
        # Get analytics
        elif query_type == "get_analytics":
            response = state.analytics.get_analytics()
        
        # Unknown query type
        else:
            response = {"error": f"Unknown query type: {query_type}"}
    
    except Exception as e:
        logger.error(f"Error handling query: {e}")
        response = {"error": str(e)}
    
    # Send response
    await websocket.send_json({
        "type": "query_response",
        "id": query_id,
        "response": response
    })

def inject_file_change(file_path: str, content: str) -> None:
    """Inject a file change for testing"""
    # Create or update file
    with open(file_path, 'w') as f:
        f.write(content)
    
    # Trigger update
    event = FileSystemEvent(file_path)
    event_handler.on_modified(event)

# Startup and shutdown events
@app.on_event("startup")
async def startup_event():
    """Startup event"""
    # Start observer
    observer.start()
    
    # Start notifications
    state.notifications.start()
    
    # Start connection manager ping
    asyncio.create_task(ping_connections())
    
    logger.info(f"{SERVER_NAME} v{VERSION} started")
    logger.info(f"Watching {state.config['watch_path']}")

@app.on_event("shutdown")
async def shutdown_event():
    """Shutdown event"""
    # Stop observer
    observer.stop()
    observer.join()
    
    # Stop notifications
    state.notifications.stop()
    
    logger.info(f"{SERVER_NAME} v{VERSION} stopped")

async def ping_connections():
    """Ping connections periodically"""
    while True:
        await state.connection_manager.ping_connections()
        await asyncio.sleep(30)  # 30 seconds

# Main entry point
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)

