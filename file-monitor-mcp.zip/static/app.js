import { Chart } from "@/components/ui/chart"
// Global variables
let socket = null
let token = null
let currentPage = "dashboard"
let authModal = null
let fileDetailsModal = null
const charts = {}

// Initialize the application
document.addEventListener("DOMContentLoaded", () => {
  // Initialize Bootstrap components
  authModal = new bootstrap.Modal(document.getElementById("auth-modal"))
  fileDetailsModal = new bootstrap.Modal(document.getElementById("file-details-modal"))

  // Set up event listeners
  setupEventListeners()

  // Check for stored token
  token = localStorage.getItem("mcp_token")
  if (token) {
    connectWebSocket()
  }

  // Show the dashboard page
  showPage("dashboard")
})

// Set up event listeners
function setupEventListeners() {
  // Navigation
  document.querySelectorAll(".nav-link").forEach((link) => {
    link.addEventListener("click", function (e) {
      e.preventDefault()
      const page = this.getAttribute("data-page")
      showPage(page)
    })
  })

  // Connect button
  document.getElementById("connect-btn").addEventListener("click", () => {
    if (socket && socket.readyState === WebSocket.OPEN) {
      disconnectWebSocket()
    } else {
      authModal.show()
    }
  })

  // Authentication form
  document.getElementById("auth-submit").addEventListener("click", () => {
    const apiKey = document.getElementById("api-key").value.trim()
    if (apiKey) {
      authenticate(apiKey)
    }
  })

  // File search
  document.getElementById("file-search").addEventListener("input", function () {
    filterFiles(this.value)
  })

  // Refresh files button
  document.getElementById("refresh-files").addEventListener("click", () => {
    loadFiles()
  })

  // Server configuration form
  document.getElementById("server-config-form").addEventListener("submit", (e) => {
    e.preventDefault()
    saveServerConfig()
  })

  // Notification configuration form
  document.getElementById("notification-config-form").addEventListener("submit", (e) => {
    e.preventDefault()
    saveNotificationConfig()
  })

  // Notification rule type change
  document.getElementById("notification-rule-type").addEventListener("change", function () {
    const ruleType = this.value
    const detailsContainer = document.getElementById("rule-details-container")
    const detailsInput = document.getElementById("rule-details")

    if (ruleType === "all_events") {
      detailsContainer.style.display = "none"
    } else {
      detailsContainer.style.display = "block"

      if (ruleType === "specific_event") {
        detailsInput.placeholder = "Event type (e.g., modified, created)"
      } else if (ruleType === "path_pattern") {
        detailsInput.placeholder = "Path pattern (e.g., *.py, src/*)"
      } else if (ruleType === "content_change") {
        detailsInput.placeholder = "Content pattern (e.g., TODO, FIXME)"
      }
    }
  })
}

// Show a specific page
function showPage(page) {
  // Hide all pages
  document.querySelectorAll(".page").forEach((p) => {
    p.style.display = "none"
  })

  // Show the selected page
  document.getElementById(`${page}-page`).style.display = "block"

  // Update navigation
  document.querySelectorAll(".nav-link").forEach((link) => {
    link.classList.remove("active")
  })
  document.querySelector(`.nav-link[data-page="${page}"]`).classList.add("active")

  // Load page-specific data
  if (page === "dashboard") {
    loadDashboard()
  } else if (page === "files") {
    loadFiles()
  } else if (page === "analytics") {
    loadAnalytics()
  } else if (page === "settings") {
    loadSettings()
  }

  currentPage = page
}

// Authenticate with the server
async function authenticate(apiKey) {
  try {
    const response = await fetch("/auth", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ api_key: apiKey }),
    })

    if (!response.ok) {
      throw new Error("Authentication failed")
    }

    const data = await response.json()
    token = data.token

    // Store token
    localStorage.setItem("mcp_token", token)

    // Close modal
    authModal.hide()

    // Connect WebSocket
    connectWebSocket()
  } catch (error) {
    showError("Authentication failed: " + error.message)
  }
}

// Connect to WebSocket
function connectWebSocket() {
  // Get WebSocket URL
  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:"
  const wsUrl = `${protocol}//${window.location.host}/mcp`

  // Create WebSocket
  socket = new WebSocket(wsUrl)

  // Set up event handlers
  socket.onopen = () => {
    // Send authentication
    socket.send(JSON.stringify({ token: token }))
  }

  socket.onmessage = (event) => {
    const message = JSON.parse(event.data)

    if (message.error) {
      showError(message.error)
      disconnectWebSocket()
      return
    }

    if (message.type === "init_response") {
      // Connection successful
      updateConnectionStatus(true)

      // Load initial data
      loadDashboard()
    } else if (message.type === "query_response") {
      // Handle query response
      handleQueryResponse(message)
    } else if (message.file_path && message.event_type) {
      // Handle file event
      handleFileEvent(message)
    }
  }

  socket.onclose = () => {
    updateConnectionStatus(false)
  }

  socket.onerror = (error) => {
    showError("WebSocket error: " + error.message)
    updateConnectionStatus(false)
  }
}

// Disconnect WebSocket
function disconnectWebSocket() {
  if (socket) {
    socket.close()
    socket = null
  }

  // Clear token
  token = null
  localStorage.removeItem("mcp_token")

  // Update UI
  updateConnectionStatus(false)
}

// Update connection status
function updateConnectionStatus(connected) {
  const statusElement = document.getElementById("connection-status")
  const connectButton = document.getElementById("connect-btn")

  if (connected) {
    statusElement.textContent = "Connected"
    statusElement.className = "badge bg-success me-2"
    connectButton.innerHTML = '<i class="bi bi-plug me-1"></i> Disconnect'
  } else {
    statusElement.textContent = "Disconnected"
    statusElement.className = "badge bg-danger me-2"
    connectButton.innerHTML = '<i class="bi bi-plug-fill me-1"></i> Connect'
  }
}

// Send a query to the server
function sendQuery(queryType, filePath = null, details = null, filters = null) {
  return new Promise((resolve, reject) => {
    if (!socket || socket.readyState !== WebSocket.OPEN) {
      reject(new Error("Not connected to server"))
      return
    }

    const queryId = "query-" + Date.now()
    const query = {
      type: "query",
      id: queryId,
      query: {
        query_type: queryType,
      },
    }

    if (filePath) {
      query.query.file_path = filePath
    }

    if (details) {
      query.query.details = details
    }

    if (filters) {
      query.query.filters = filters
    }

    // Set up response handler
    const responseHandler = (event) => {
      const message = JSON.parse(event.data)

      if (message.type === "query_response" && message.id === queryId) {
        socket.removeEventListener("message", responseHandler)
        resolve(message.response)
      }
    }

    socket.addEventListener("message", responseHandler)

    // Send query
    socket.send(JSON.stringify(query))

    // Set timeout
    setTimeout(() => {
      socket.removeEventListener("message", responseHandler)
      reject(new Error("Query timed out"))
    }, 10000)
  })
}

// Handle query response
function handleQueryResponse(message) {
  // This is handled by the Promise in sendQuery
}

// Handle file event
function handleFileEvent(message) {
  // Add to recent activity
  addRecentActivity(message)

  // Update dashboard if current page
  if (currentPage === "dashboard") {
    loadDashboard()
  }

  // Update files list if current page
  if (currentPage === "files") {
    loadFiles()
  }
}

// Load dashboard data
async function loadDashboard() {
  if (!socket || socket.readyState !== WebSocket.OPEN) {
    return
  }

  try {
    // Get server stats
    const stats = await sendQuery("get_server_stats")

    // Update stats
    document.getElementById("file-count").textContent = stats.file_count
    document.getElementById("uptime").textContent = formatDuration(stats.uptime)
    document.getElementById("client-count").textContent = stats.client_count

    // Get recent changes
    const recentChanges = await sendQuery("get_recent_changes", null, { limit: 10 })

    // Update recent changes count
    document.getElementById("recent-changes-count").textContent = Object.keys(recentChanges.recent_changes || {}).length

    // Update recent activity
    const activityContainer = document.getElementById("recent-activity")
    activityContainer.innerHTML = ""

    if (Object.keys(recentChanges.recent_changes || {}).length === 0) {
      activityContainer.innerHTML = `
                <div class="text-center text-muted py-3">
                    <i class="bi bi-hourglass me-2"></i>
                    No recent activity
                </div>
            `
    } else {
      for (const [filePath, message] of Object.entries(recentChanges.recent_changes)) {
        const timestamp = new Date(message.timestamp * 1000)
        const fileName = filePath.split("/").pop()

        const item = document.createElement("a")
        item.href = "#"
        item.className = "list-group-item list-group-item-action"
        item.innerHTML = `
                    <div class="d-flex w-100 justify-content-between">
                        <h6 class="mb-1">${fileName}</h6>
                        <small>${formatTimestamp(timestamp)}</small>
                    </div>
                    <p class="mb-1 text-truncate">${filePath}</p>
                    <small class="text-muted">
                        <span class="badge bg-${message.role === "system" ? "primary" : message.role === "assistant" ? "success" : "warning"}">
                            ${message.role}
                        </span>
                        ${message.content.substring(0, 50)}${message.content.length > 50 ? "..." : ""}
                    </small>
                `

        item.addEventListener("click", (e) => {
          e.preventDefault()
          showFileDetails(filePath)
        })

        activityContainer.appendChild(item)
      }
    }

    // Get analytics
    const analytics = await sendQuery("get_analytics")

    // Update most active files
    const activeFilesContainer = document.getElementById("active-files")
    activeFilesContainer.innerHTML = ""

    if (!analytics.most_active_files || Object.keys(analytics.most_active_files).length === 0) {
      activeFilesContainer.innerHTML = `
                <div class="text-center text-muted py-3">
                    <i class="bi bi-hourglass me-2"></i>
                    No active files
                </div>
            `
    } else {
      for (const [filePath, count] of Object.entries(analytics.most_active_files)) {
        const fileName = filePath.split("/").pop()

        const item = document.createElement("a")
        item.href = "#"
        item.className = "list-group-item list-group-item-action"
        item.innerHTML = `
                    <div class="d-flex w-100 justify-content-between">
                        <h6 class="mb-1">${fileName}</h6>
                        <small>${count} changes</small>
                    </div>
                    <p class="mb-1 text-truncate">${filePath}</p>
                `

        item.addEventListener("click", (e) => {
          e.preventDefault()
          showFileDetails(filePath)
        })

        activeFilesContainer.appendChild(item)
      }
    }
  } catch (error) {
    showError("Error loading dashboard: " + error.message)
  }
}

// Load files data
async function loadFiles() {
  if (!socket || socket.readyState !== WebSocket.OPEN) {
    return
  }

  try {
    // Get all files
    const response = await sendQuery("get_all_files")

    // Update files table
    const tableBody = document.getElementById("files-table-body")
    tableBody.innerHTML = ""

    if (!response.files || response.files.length === 0) {
      tableBody.innerHTML = `
                <tr>
                    <td colspan="4" class="text-center">No files found</td>
                </tr>
            `
    } else {
      for (const file of response.files) {
        const row = document.createElement("tr")

        const lastModified = new Date(file.last_modified * 1000)

        row.innerHTML = `
                    <td class="text-truncate" style="max-width: 300px;">${file.path}</td>
                    <td>${formatTimestamp(lastModified)}</td>
                    <td>${file.message_count}</td>
                    <td>
                        <button class="btn btn-sm btn-primary view-file" data-file="${file.path}">
                            <i class="bi bi-eye"></i>
                        </button>
                    </td>
                `

        tableBody.appendChild(row)
      }

      // Add event listeners
      document.querySelectorAll(".view-file").forEach((button) => {
        button.addEventListener("click", function () {
          const filePath = this.getAttribute("data-file")
          showFileDetails(filePath)
        })
      })
    }
  } catch (error) {
    showError("Error loading files: " + error.message)
  }
}

// Load analytics data
async function loadAnalytics() {
  if (!socket || socket.readyState !== WebSocket.OPEN) {
    return
  }

  try {
    // Get analytics data
    const analytics = await sendQuery("get_analytics")

    // Create charts
    createEventChart(analytics.event_counts || {})
    createFileTypeChart(analytics.file_type_distribution || {})
    createActivityChart(analytics.activity_over_time || {})
  } catch (error) {
    showError("Error loading analytics: " + error.message)
  }
}

// Load settings data
async function loadSettings() {
  if (!socket || socket.readyState !== WebSocket.OPEN) {
    return
  }

  try {
    // Get server stats for current configuration
    const stats = await sendQuery("get_server_stats")

    // Update form fields
    document.getElementById("watch-path").value = stats.watch_path || ""
    document.getElementById("file-patterns").value = (stats.file_patterns || []).join(",")
    document.getElementById("max-file-size").value = stats.max_file_size || ""
  } catch (error) {
    showError("Error loading settings: " + error.message)
  }
}

// Save server configuration
async function saveServerConfig() {
  if (!socket || socket.readyState !== WebSocket.OPEN) {
    return
  }

  try {
    const watchPath = document.getElementById("watch-path").value.trim()
    const filePatternsStr = document.getElementById("file-patterns").value.trim()
    const maxFileSize = document.getElementById("max-file-size").value.trim()

    const config = {}

    if (watchPath) {
      config.watch_path = watchPath
    }

    if (filePatternsStr) {
      config.file_patterns = filePatternsStr
        .split(",")
        .map((p) => p.trim())
        .filter((p) => p)
    }

    if (maxFileSize) {
      config.max_file_size = Number.parseInt(maxFileSize, 10)
    }

    // Send configuration
    const response = await fetch("/config", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-API-Key": document.getElementById("api-key").value.trim(),
      },
      body: JSON.stringify(config),
    })

    if (!response.ok) {
      throw new Error("Failed to save configuration")
    }

    showSuccess("Configuration saved successfully")
  } catch (error) {
    showError("Error saving configuration: " + error.message)
  }
}

// Save notification configuration
async function saveNotificationConfig() {
  if (!socket || socket.readyState !== WebSocket.OPEN) {
    return
  }

  try {
    const webhookUrl = document.getElementById("webhook-url").value.trim()
    const ruleType = document.getElementById("notification-rule-type").value
    const ruleDetails = document.getElementById("rule-details").value.trim()

    const config = {}

    if (webhookUrl) {
      config.webhook_url = webhookUrl
    }

    if (ruleType) {
      config.rule = { type: ruleType }

      if (ruleType !== "all_events" && ruleDetails) {
        if (ruleType === "specific_event") {
          config.rule.event_type = ruleDetails
        } else if (ruleType === "path_pattern") {
          config.rule.pattern = ruleDetails
        } else if (ruleType === "content_change") {
          config.rule.content_pattern = ruleDetails
        }
      }
    }

    // Send configuration
    const response = await fetch("/notifications/config", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-API-Key": document.getElementById("api-key").value.trim(),
      },
      body: JSON.stringify(config),
    })

    if (!response.ok) {
      throw new Error("Failed to save notification settings")
    }

    showSuccess("Notification settings saved successfully")
  } catch (error) {
    showError("Error saving notification settings: " + error.message)
  }
}

// Show file details
async function showFileDetails(filePath) {
  if (!socket || socket.readyState !== WebSocket.OPEN) {
    return
  }

  try {
    // Get file history
    const fileHistory = await sendQuery("get_file_history", filePath)

    // Update modal title
    document.getElementById("file-details-title").textContent = filePath.split("/").pop()

    // Update content tab
    const contentCode = document.getElementById("file-content-code")
    contentCode.textContent = fileHistory.content || "No content available"
    hljs.highlightElement(contentCode)

    // Update history tab
    const historyContent = document.getElementById("file-history-content")
    historyContent.innerHTML = ""

    if (!fileHistory.messages || fileHistory.messages.length === 0) {
      historyContent.innerHTML = `
                <div class="alert alert-info">No history available</div>
            `
    } else {
      for (const message of fileHistory.messages) {
        const timestamp = new Date(message.timestamp * 1000)

        const messageDiv = document.createElement("div")
        messageDiv.className = "card mb-3"
        messageDiv.innerHTML = `
                    <div class="card-header bg-${message.role === "system" ? "primary" : message.role === "assistant" ? "success" : "warning"} text-white">
                        <div class="d-flex justify-content-between align-items-center">
                            <span>${message.role}</span>
                            <small>${formatTimestamp(timestamp)}</small>
                        </div>
                    </div>
                    <div class="card-body">
                        <pre class="mb-0">${message.content}</pre>
                    </div>
                `

        historyContent.appendChild(messageDiv)
      }
    }

    // Update diff tab
    const diffCode = document.getElementById("file-diff-code")
    diffCode.textContent = fileHistory.diff || "No diff available"
    hljs.highlightElement(diffCode)

    // Show modal
    fileDetailsModal.show()
  } catch (error) {
    showError("Error loading file details: " + error.message)
  }
}

// Filter files
function filterFiles(query) {
  query = query.toLowerCase()

  const rows = document.querySelectorAll("#files-table-body tr")

  rows.forEach((row) => {
    const filePath = row.querySelector("td:first-child").textContent.toLowerCase()

    if (filePath.includes(query)) {
      row.style.display = ""
    } else {
      row.style.display = "none"
    }
  })
}

// Add recent activity
function addRecentActivity(event) {
  const activityContainer = document.getElementById("recent-activity")

  // Remove "no activity" message if present
  const noActivity = activityContainer.querySelector(".text-muted")
  if (noActivity) {
    activityContainer.innerHTML = ""
  }

  // Create activity item
  const timestamp = new Date(event.timestamp * 1000)
  const fileName = event.file_path.split("/").pop()

  const item = document.createElement("a")
  item.href = "#"
  item.className = "list-group-item list-group-item-action"
  item.innerHTML = `
        <div class="d-flex w-100 justify-content-between">
            <h6 class="mb-1">${fileName}</h6>
            <small>${formatTimestamp(timestamp)}</small>
        </div>
        <p class="mb-1 text-truncate">${event.file_path}</p>
        <small class="text-muted">
            <span class="badge bg-info">
                ${event.event_type}
            </span>
            ${event.content_changed ? '<span class="badge bg-warning">Content changed</span>' : ""}
        </small>
    `

  item.addEventListener("click", (e) => {
    e.preventDefault()
    showFileDetails(event.file_path)
  })

  // Add to container
  activityContainer.insertBefore(item, activityContainer.firstChild)

  // Limit to 10 items
  while (activityContainer.children.length > 10) {
    activityContainer.removeChild(activityContainer.lastChild)
  }
}

// Create event chart
function createEventChart(eventCounts) {
  const ctx = document.getElementById("event-chart").getContext("2d")

  if (charts.eventChart) {
    charts.eventChart.destroy()
  }

  const labels = Object.keys(eventCounts)
  const data = Object.values(eventCounts)

  charts.eventChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: labels,
      datasets: [
        {
          label: "Event Count",
          data: data,
          backgroundColor: "rgba(54, 162, 235, 0.5)",
          borderColor: "rgba(54, 162, 235, 1)",
          borderWidth: 1,
        },
      ],
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  })
}

// Create file type chart
function createFileTypeChart(fileTypes) {
  const ctx = document.getElementById("file-type-chart").getContext("2d")

  if (charts.fileTypeChart) {
    charts.fileTypeChart.destroy()
  }

  const labels = Object.keys(fileTypes)
  const data = Object.values(fileTypes)

  // Generate colors
  const colors = []
  for (let i = 0; i < labels.length; i++) {
    const hue = (i * 137) % 360
    colors.push(`hsla(${hue}, 70%, 60%, 0.7)`)
  }

  charts.fileTypeChart = new Chart(ctx, {
    type: "pie",
    data: {
      labels: labels,
      datasets: [
        {
          data: data,
          backgroundColor: colors,
          borderWidth: 1,
        },
      ],
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: "right",
        },
      },
    },
  })
}

// Create activity chart
function createActivityChart(activityData) {
  const ctx = document.getElementById("activity-chart").getContext("2d")

  if (charts.activityChart) {
    charts.activityChart.destroy()
  }

  // Default to empty data if not provided
  const timeLabels = []
  const counts = []

  if (Object.keys(activityData).length > 0) {
    // Sort by timestamp
    const sortedTimes = Object.keys(activityData).sort()

    for (const time of sortedTimes) {
      const date = new Date(Number.parseInt(time) * 1000)
      timeLabels.push(formatTimestamp(date))
      counts.push(activityData[time])
    }
  } else {
    // Generate some empty data for display
    const now = new Date()
    for (let i = 6; i >= 0; i--) {
      const date = new Date(now)
      date.setDate(date.getDate() - i)
      timeLabels.push(formatTimestamp(date))
      counts.push(0)
    }
  }

  charts.activityChart = new Chart(ctx, {
    type: "line",
    data: {
      labels: timeLabels,
      datasets: [
        {
          label: "Activity",
          data: counts,
          fill: false,
          borderColor: "rgba(75, 192, 192, 1)",
          tension: 0.1,
        },
      ],
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  })
}

// Format timestamp
function formatTimestamp(date) {
  return moment(date).format("YYYY-MM-DD HH:MM:SS")
}

// Format duration
function formatDuration(seconds) {
  const days = Math.floor(seconds / 86400)
  const hours = Math.floor((seconds % 86400) / 3600)
  const minutes = Math.floor((seconds % 3600) / 60)
  const secs = Math.floor(seconds % 60)

  const parts = []
  if (days > 0) parts.push(`${days}d`)
  if (hours > 0) parts.push(`${hours}h`)
  if (minutes > 0) parts.push(`${minutes}m`)
  if (secs > 0 || parts.length === 0) parts.push(`${secs}s`)

  return parts.join(" ")
}

// Show error message
function showError(message) {
  console.error(message)

  // Create alert
  const alert = document.createElement("div")
  alert.className = "alert alert-danger alert-dismissible fade show position-fixed top-0 end-0 m-3"
  alert.setAttribute("role", "alert")
  alert.innerHTML = `
        <strong>Error:</strong> ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `

  // Add to document
  document.body.appendChild(alert)

  // Remove after 5 seconds
  setTimeout(() => {
    alert.remove()
  }, 5000)
}

// Show success message
function showSuccess(message) {
  // Create alert
  const alert = document.createElement("div")
  alert.className = "alert alert-success alert-dismissible fade show position-fixed top-0 end-0 m-3"
  alert.setAttribute("role", "alert")
  alert.innerHTML = `
        <strong>Success:</strong> ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `

  // Add to document
  document.body.appendChild(alert)

  // Remove after 5 seconds
  setTimeout(() => {
    alert.remove()
  }, 5000)
}

