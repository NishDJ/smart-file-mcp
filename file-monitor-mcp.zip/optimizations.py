import os
import time
import logging
import asyncio
from typing import Dict, List, Set, Optional, Any
from concurrent.futures import ThreadPoolExecutor
import fnmatch
import hashlib

logger = logging.getLogger("file-monitor-mcp.optimizations")

class FileIndexer:
    """Optimized file indexer for large directories"""
    def __init__(self, max_workers: int = 4):
        self.max_workers = max_workers
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self.file_cache: Dict[str, Dict[str, Any]] = {}
        self.last_scan_time = 0
        self.scan_in_progress = False
    
    async def scan_directory(self, directory: str, patterns: List[str] = None, 
                           max_size: int = 1024 * 1024, 
                           skip_hidden: bool = True) -> Dict[str, Dict[str, Any]]:
        """Scan a directory for files matching patterns"""
        if self.scan_in_progress:
            logger.info("Scan already in progress, waiting for completion")
            while self.scan_in_progress:
                await asyncio.sleep(0.1)
            return self.file_cache
        
        self.scan_in_progress = True
        start_time = time.time()
        
        try:
            loop = asyncio.get_event_loop()
            
            # Get all files in directory
            all_files = await loop.run_in_executor(
                self.executor, 
                self._get_all_files, 
                directory, 
                patterns, 
                max_size, 
                skip_hidden
            )
            
            # Process files in batches
            batch_size = 100
            batches = [all_files[i:i + batch_size] for i in range(0, len(all_files), batch_size)]
            
            new_cache = {}
            for batch in batches:
                # Process batch in parallel
                tasks = []
                for file_path in batch:
                    task = loop.run_in_executor(
                        self.executor,
                        self._process_file,
                        file_path
                    )
                    tasks.append(task)
                
                # Wait for batch to complete
                results = await asyncio.gather(*tasks)
                
                # Update cache
                for file_path, file_info in results:
                    if file_info:
                        new_cache[file_path] = file_info
            
            # Update cache
            self.file_cache = new_cache
            self.last_scan_time = time.time()
            
            logger.info(f"Scanned {len(self.file_cache)} files in {time.time() - start_time:.2f} seconds")
            return self.file_cache
        
        finally:
            self.scan_in_progress = False
    
    def _get_all_files(self, directory: str, patterns: List[str], 
                      max_size: int, skip_hidden: bool) -> List[str]:
        """Get all files in directory matching patterns"""
        all_files = []
        
        for root, dirs, files in os.walk(directory):
            # Skip hidden directories
            if skip_hidden:
                dirs[:] = [d for d in dirs if not d.startswith('.')]
            
            for file in files:
                # Skip hidden files
                if skip_hidden and file.startswith('.'):
                    continue
                
                file_path = os.path.join(root, file)
                
                # Skip files that are too large
                try:
                    if os.path.getsize(file_path) > max_size:
                        continue
                except OSError:
                    continue
                
                # Apply patterns
                if patterns:
                    match = False
                    for pattern in patterns:
                        if pattern.startswith('!'):
                            # Exclude pattern
                            if fnmatch.fnmatch(file, pattern[1:]):
                                match = False
                                break
                        elif fnmatch.fnmatch(file, pattern):
                            match = True
                    
                    if not match:
                        continue
                
                all_files.append(file_path)
        
        return all_files
    
    def _process_file(self, file_path: str) -> tuple:
        """Process a file and return its information"""
        try:
            stat = os.stat(file_path)
            
            # Check if file is in cache and hasn't changed
            if file_path in self.file_cache:
                cached = self.file_cache[file_path]
                if cached["mtime"] == stat.st_mtime and cached["size"] == stat.st_size:
                    return file_path, cached
            
            # Read file content for small files
            content = None
            content_hash = None
            
            if stat.st_size <= 1024 * 1024:  # 1MB max for content
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    content_hash = hashlib.md5(content.encode()).hexdigest()
                except (UnicodeDecodeError, IOError):
                    # Not a text file or can't read
                    pass
            
            file_info = {
                "path": file_path,
                "size": stat.st_size,
                "mtime": stat.st_mtime,
                "ctime": stat.st_ctime,
                "content": content,
                "content_hash": content_hash
            }
            
            return file_path, file_info
        
        except Exception as e:
            logger.error(f"Error processing file {file_path}: {e}")
            return file_path, None
    
    def get_file_info(self, file_path: str) -> Optional[Dict[str, Any]]:
        """Get information about a specific file"""
        if file_path in self.file_cache:
            return self.file_cache[file_path]
        
        try:
            _, file_info = self._process_file(file_path)
            if file_info:
                self.file_cache[file_path] = file_info
            return file_info
        except Exception as e:
            logger.error(f"Error getting file info for {file_path}: {e}")
            return None
    
    def get_changed_files(self, directory: str, patterns: List[str] = None,
                         max_size: int = 1024 * 1024,
                         skip_hidden: bool = True) -> Dict[str, str]:
        """Get files that have changed since last scan"""
        old_cache = self.file_cache.copy()
        
        # Scan directory
        loop = asyncio.get_event_loop()
        asyncio.run_coroutine_threadsafe(
            self.scan_directory(directory, patterns, max_size, skip_hidden),
            loop
        )
        
        # Find changed files
        changed_files = {}
        
        # New or modified files
        for file_path, file_info in self.file_cache.items():
            if file_path not in old_cache:
                changed_files[file_path] = "created"
            elif (file_info["mtime"] != old_cache[file_path]["mtime"] or
                  file_info["content_hash"] != old_cache[file_path]["content_hash"]):
                changed_files[file_path] = "modified"
        
        # Deleted files
        for file_path in old_cache:
            if file_path not in self.file_cache:
                changed_files[file_path] = "deleted"
        
        return changed_files

class MemoryOptimizer:
    """Memory usage optimizer"""
    def __init__(self, max_memory_mb: int = 500):
        self.max_memory_mb = max_memory_mb
        self.last_cleanup_time = 0
        self.cleanup_interval = 300  # 5 minutes
    
    def check_memory_usage(self) -> bool:
        """Check if memory usage is above threshold"""
        try:
            import psutil
            process = psutil.Process(os.getpid())
            memory_info = process.memory_info()
            memory_mb = memory_info.rss / 1024 / 1024
            
            return memory_mb > self.max_memory_mb
        except ImportError:
            # psutil not available
            return False
    
    def optimize_memory(self, state: Any) -> None:
        """Optimize memory usage by cleaning up caches"""
        current_time = time.time()
        
        # Only run cleanup if interval has passed
        if current_time - self.last_cleanup_time < self.cleanup_interval:
            return
        
        self.last_cleanup_time = current_time
        
        if not self.check_memory_usage():
            return
        
        logger.info("Memory usage above threshold, cleaning up caches")
        
        # Clean up file content cache
        files_cleaned = 0
        for file_path, conversation in list(state.conversations.items()):
            # Keep only the most recent content
            if hasattr(conversation, 'previous_content') and conversation.previous_content:
                conversation.previous_content = None
                files_cleaned += 1
        
        logger.info(f"Cleaned up content cache for {files_cleaned} files")
        
        # Force garbage collection
        import gc
        gc.collect()

class ConnectionManager:
    """WebSocket connection manager with optimizations"""
    def __init__(self):
        self.active_connections: Set[Any] = set()
        self.connection_info: Dict[Any, Dict[str, Any]] = {}
        self.last_ping_time: Dict[Any, float] = {}
        self.ping_interval = 30  # 30 seconds
        self.ping_timeout = 60  # 60 seconds
    
    def add_connection(self, connection: Any, client_info: Dict[str, Any] = None) -> None:
        """Add a new connection"""
        self.active_connections.add(connection)
        self.connection_info[connection] = client_info or {}
        self.last_ping_time[connection] = time.time()
    
    def remove_connection(self, connection: Any) -> None:
        """Remove a connection"""
        self.active_connections.discard(connection)
        self.connection_info.pop(connection, None)
        self.last_ping_time.pop(connection, None)
    
    async def send_to_all(self, message: Any) -> None:
        """Send a message to all connections"""
        disconnected = set()
        
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Error sending message to connection: {e}")
                disconnected.add(connection)
        
        # Remove disconnected connections
        for connection in disconnected:
            self.remove_connection(connection)
    
    async def send_to_filtered(self, message: Any, filter_func: callable) -> None:
        """Send a message to connections that match a filter"""
        disconnected = set()
        
        for connection in self.active_connections:
            try:
                if filter_func(connection, self.connection_info.get(connection, {})):
                    await connection.send_json(message)
            except Exception as e:
                logger.error(f"Error sending message to connection: {e}")
                disconnected.add(connection)
        
        # Remove disconnected connections
        for connection in disconnected:
            self.remove_connection(connection)
    
    async def ping_connections(self) -> None:
        """Ping connections to check if they're still alive"""
        current_time = time.time()
        disconnected = set()
        
        for connection in self.active_connections:
            try:
                # Check if connection has timed out
                last_ping = self.last_ping_time.get(connection, 0)
                if current_time - last_ping > self.ping_timeout:
                    logger.info(f"Connection timed out")
                    disconnected.add(connection)
                    continue
                
                # Send ping if interval has passed
                if current_time - last_ping > self.ping_interval:
                    await connection.send_json({
                        "type": "ping",
                        "id": f"ping-{int(current_time * 1000)}",
                        "server_time": current_time
                    })
                    self.last_ping_time[connection] = current_time
            except Exception as e:
                logger.error(f"Error pinging connection: {e}")
                disconnected.add(connection)
        
        # Remove disconnected connections
        for connection in disconnected:
            self.remove_connection(connection)
    
    def get_connection_stats(self) -> Dict[str, Any]:
        """Get connection statistics"""
        stats = {
            "total_connections": len(self.active_connections),
            "connection_info": {}
        }
        
        # Group connections by client info
        for connection, info in self.connection_info.items():
            client_id = info.get("client_id", "unknown")
            if client_id not in stats["connection_info"]:
                stats["connection_info"][client_id] = 0
            stats["connection_info"][client_id] += 1
        
        return stats

