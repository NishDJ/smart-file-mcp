import os
import time
import hmac
import hashlib
import base64
import json
import secrets
import logging
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
from fastapi import Depends, HTTPException, Security, Request
from fastapi.security import APIKeyHeader, HTTPBearer, HTTPAuthorizationCredentials

logger = logging.getLogger("file-monitor-mcp.security")

# Security settings
API_KEY_NAME = "X-API-Key"
api_key_header = APIKeyHeader(name=API_KEY_NAME, auto_error=False)
token_auth = HTTPBearer(auto_error=False)

# Rate limiting
rate_limits = {
    "default": {"requests": 100, "window": 60},  # 100 requests per minute
    "auth": {"requests": 10, "window": 60},      # 10 auth requests per minute
    "query": {"requests": 50, "window": 60}      # 50 query requests per minute
}

# IP tracking for rate limiting
ip_request_counts: Dict[str, Dict[str, List[float]]] = {}

class SecurityManager:
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.environ.get("MCP_API_KEY", "dev-api-key-change-me-in-production")
        self.token_secret = os.environ.get("MCP_TOKEN_SECRET", secrets.token_hex(32))
        self.blocked_ips: Dict[str, float] = {}  # IP -> block expiry time
        self.suspicious_activity: Dict[str, List[Dict[str, Any]]] = {}  # IP -> list of suspicious activities
    
    def verify_api_key(self, api_key: str) -> bool:
        """Verify API key"""
        return hmac.compare_digest(api_key, self.api_key)
    
    def create_token(self, data: dict, expires_delta: Optional[timedelta] = None) -> Tuple[str, datetime]:
        """Create a JWT-like token"""
        to_encode = data.copy()
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(hours=24)
        to_encode.update({"exp": expire.timestamp()})
        
        # Create a simple token with HMAC
        message = json.dumps(to_encode).encode()
        signature = hmac.new(self.token_secret.encode(), message, hashlib.sha256).digest()
        token = base64.urlsafe_b64encode(message + b"." + signature).decode()
        
        return token, expire
    
    def verify_token(self, token: str) -> Optional[Dict[str, Any]]:
        """Verify a JWT-like token"""
        try:
            decoded = base64.urlsafe_b64decode(token)
            message_part, signature_part = decoded.split(b".", 1)
            
            # Verify signature
            expected_signature = hmac.new(self.token_secret.encode(), message_part, hashlib.sha256).digest()
            if not hmac.compare_digest(signature_part, expected_signature):
                return None
            
            # Parse message
            data = json.loads(message_part)
            
            # Check expiration
            if data.get("exp", 0) < datetime.utcnow().timestamp():
                return None
                
            return data
        except Exception as e:
            logger.error(f"Token verification error: {e}")
            return None
    
    def check_rate_limit(self, ip: str, endpoint_type: str = "default") -> bool:
        """Check if request is within rate limits"""
        # Check if IP is blocked
        if ip in self.blocked_ips:
            if time.time() < self.blocked_ips[ip]:
                return False
            else:
                # Unblock IP
                del self.blocked_ips[ip]
        
        # Initialize tracking for this IP if needed
        if ip not in ip_request_counts:
            ip_request_counts[ip] = {}
        
        if endpoint_type not in ip_request_counts[ip]:
            ip_request_counts[ip][endpoint_type] = []
        
        # Get rate limit for this endpoint type
        limit = rate_limits.get(endpoint_type, rate_limits["default"])
        requests_limit = limit["requests"]
        window = limit["window"]
        
        # Clean up old requests
        current_time = time.time()
        ip_request_counts[ip][endpoint_type] = [
            t for t in ip_request_counts[ip][endpoint_type] 
            if current_time - t < window
        ]
        
        # Check if over limit
        if len(ip_request_counts[ip][endpoint_type]) >= requests_limit:
            # Record suspicious activity
            self._record_suspicious_activity(ip, "rate_limit_exceeded", {
                "endpoint_type": endpoint_type,
                "requests": len(ip_request_counts[ip][endpoint_type]),
                "limit": requests_limit,
                "window": window
            })
            return False
        
        # Add current request
        ip_request_counts[ip][endpoint_type].append(current_time)
        return True
    
    def block_ip(self, ip: str, duration: int = 3600):
        """Block an IP for a specified duration (in seconds)"""
        self.blocked_ips[ip] = time.time() + duration
        logger.warning(f"Blocked IP {ip} for {duration} seconds")
    
    def _record_suspicious_activity(self, ip: str, activity_type: str, details: Dict[str, Any]):
        """Record suspicious activity"""
        if ip not in self.suspicious_activity:
            self.suspicious_activity[ip] = []
        
        self.suspicious_activity[ip].append({
            "type": activity_type,
            "timestamp": time.time(),
            "details": details
        })
        
        # Check if we should block this IP
        if len(self.suspicious_activity[ip]) >= 5:
            recent_activities = [
                a for a in self.suspicious_activity[ip]
                if time.time() - a["timestamp"] < 3600  # Last hour
            ]
            
            if len(recent_activities) >= 5:
                self.block_ip(ip)
    
    def sanitize_input(self, data: Any) -> Any:
        """Sanitize input data to prevent injection attacks"""
        if isinstance(data, str):
            # Basic sanitization for strings
            return data.replace("<script", "&lt;script").replace("</script", "&lt;/script")
        elif isinstance(data, dict):
            # Recursively sanitize dictionaries
            return {k: self.sanitize_input(v) for k, v in data.items()}
        elif isinstance(data, list):
            # Recursively sanitize lists
            return [self.sanitize_input(item) for item in data]
        else:
            # Return other types unchanged
            return data
    
    def get_client_ip(self, request: Request) -> str:
        """Get client IP address from request"""
        forwarded = request.headers.get("X-Forwarded-For")
        if forwarded:
            return forwarded.split(",")[0].strip()
        return request.client.host if request.client else "unknown"
    
    async def get_current_api_key(self, api_key: str = Depends(api_key_header), request: Request = None):
        """Dependency for API key authentication"""
        if request:
            client_ip = self.get_client_ip(request)
            
            # Check rate limit
            if not self.check_rate_limit(client_ip, "auth"):
                raise HTTPException(
                    status_code=429,
                    detail="Too many authentication attempts"
                )
        
        if self.verify_api_key(api_key):
            return api_key
        
        # Record failed authentication
        if request:
            self._record_suspicious_activity(client_ip, "invalid_api_key", {})
        
        raise HTTPException(
            status_code=401,
            detail="Invalid API Key",
            headers={"WWW-Authenticate": "ApiKey"},
        )
    
    async def get_current_token(self, auth: HTTPAuthorizationCredentials = Security(token_auth), request: Request = None):
        """Dependency for token authentication"""
        if request:
            client_ip = self.get_client_ip(request)
            
            # Check rate limit
            if not self.check_rate_limit(client_ip, "auth"):
                raise HTTPException(
                    status_code=429,
                    detail="Too many authentication attempts"
                )
        
        if not auth:
            raise HTTPException(
                status_code=401,
                detail="Authentication required",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        token_data = self.verify_token(auth.credentials)
        if not token_data:
            # Record failed authentication
            if request:
                self._record_suspicious_activity(client_ip, "invalid_token", {})
            
            raise HTTPException(
                status_code=401,
                detail="Invalid or expired token",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        return token_data

