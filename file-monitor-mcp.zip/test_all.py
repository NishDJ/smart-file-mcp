#!/usr/bin/env python3
import unittest
import os
import sys
import tempfile
import shutil
import time
import json
import asyncio
import subprocess
import signal
import requests
from unittest.mock import patch, MagicMock
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("file-monitor-mcp-tests")

# Import our modules
from server import FileConversation, FileMonitorState, inject_file_change
from persistence import PersistenceManager
from analytics import FileAnalytics
from notifications import NotificationManager
from security import SecurityManager
from optimizations import FileIndexer, MemoryOptimizer, ConnectionManager

class TestFileConversation(unittest.TestCase):
    def setUp(self):
        # Create a temporary directory for test files
        self.test_dir = tempfile.mkdtemp()
        self.test_file = os.path.join(self.test_dir, "test_file.txt")
        
        # Create a test file
        with open(self.test_file, "w") as f:
            f.write("Initial content")
    
    def tearDown(self):
        # Clean up temporary directory
        shutil.rmtree(self.test_dir)
    
    def test_init(self):
        """Test FileConversation initialization"""
        conv = FileConversation(self.test_file)
        self.assertEqual(conv.file_path, self.test_file)
        self.assertEqual(conv.content, "Initial content")
        self.assertIsNotNone(conv.content_hash)
        self.assertEqual(len(conv.messages), 0)
    
    def test_update_content(self):
        """Test content update detection"""
        conv = FileConversation(self.test_file)
        
        # No change
        self.assertFalse(conv.update_content())
        
        # Modify file
        with open(self.test_file, "w") as f:
            f.write("Modified content")
        
        # Should detect change
        self.assertTrue(conv.update_content())
        self.assertEqual(conv.content, "Modified content")
        self.assertEqual(conv.previous_content, "Initial content")
    
    def test_add_message(self):
        """Test adding messages"""
        conv = FileConversation(self.test_file)
        
        # Add a message
        msg = conv.add_message("system", "Test message")
        
        self.assertEqual(len(conv.messages), 1)
        self.assertEqual(msg["role"], "system")
        self.assertEqual(msg["content"], "Test message")
        self.assertIn("timestamp", msg)
        self.assertIn("id", msg)
    
    def test_generate_diff(self):
        """Test diff generation"""
        conv = FileConversation(self.test_file)
        
        # No previous content yet
        self.assertIsNone(conv.generate_diff())
        
        # Modify file to create previous content
        with open(self.test_file, "w") as f:
            f.write("Modified content")
        
        conv.update_content()
        
        # Modify again
        with open(self.test_file, "w") as f:
            f.write("Modified again")
        
        conv.update_content()
        
        # Should have a diff now
        diff = conv.generate_diff()
        self.assertIsNotNone(diff)
        self.assertIn("-Modified content", diff)
        self.assertIn("+Modified again", diff)

class TestPersistence(unittest.TestCase):
    def setUp(self):
        # Create a temporary database
        self.db_path = tempfile.mktemp(suffix=".db")
        self.persistence = PersistenceManager(self.db_path)
        
        # Create a test file
        self.test_dir = tempfile.mkdtemp()
        self.test_file = os.path.join(self.test_dir, "test_file.txt")
        with open(self.test_file, "w") as f:
            f.write("Test content")
    
    def tearDown(self):
        # Clean up
        if os.path.exists(self.db_path):
            os.unlink(self.db_path)
        shutil.rmtree(self.test_dir)
    
    def test_save_and_get_message(self):
        """Test saving and retrieving messages"""
        # Save a message
        message = {
            "role": "system",
            "content": "Test message",
            "timestamp": time.time(),
            "id": "test-id"
        }
        
        self.assertTrue(self.persistence.save_message(self.test_file, message))
        
        # Get messages
        messages = self.persistence.get_messages(self.test_file)
        
        self.assertEqual(len(messages), 1)
        self.assertEqual(messages[0]["role"], "system")
        self.assertEqual(messages[0]["content"], "Test message")
        self.assertEqual(messages[0]["id"], "test-id")
    
    def test_save_and_get_file_content(self):
        """Test saving and retrieving file content"""
        # Save file content
        content = "Test content"
        content_hash = "test-hash"
        
        self.assertTrue(self.persistence.save_file_content(self.test_file, content, content_hash))
        
        # Get file history
        history = self.persistence.get_file_history(self.test_file)
        
        self.assertEqual(len(history), 1)
        self.assertEqual(history[0]["content"], "Test content")
        self.assertEqual(history[0]["content_hash"], "test-hash")
    
    def test_get_all_files(self):
        """Test getting all files"""
        # Save some file content
        self.persistence.save_file_content(self.test_file, "Test content", "test-hash")
        
        # Get all files
        files = self.persistence.get_all_files()
        
        self.assertEqual(len(files), 1)
        self.assertEqual(files[0]["path"], self.test_file)
    
    def test_cleanup_old_data(self):
        """Test cleaning up old data"""
        # Save file content
        self.persistence.save_file_content(self.test_file, "Test content", "test-hash")
        
        # Save another version with a timestamp in the past
        conn = self.persistence._get_connection()
        cursor = conn.cursor()
        
        file_id = self.persistence.get_file_id(self.test_file)
        old_timestamp = time.time() - (31 * 24 * 60 * 60)  # 31 days ago
        
        cursor.execute(
            "INSERT INTO file_contents (file_id, content, content_hash, timestamp) VALUES (?, ?, ?, ?)",
            (file_id, "Old content", "old-hash", old_timestamp)
        )
        
        conn.commit()
        conn.close()
        
        # Clean up old data
        deleted_count = self.persistence.cleanup_old_data(max_age_days=30)
        
        # Should have deleted one record
        self.assertEqual(deleted_count, 1)
        
        # Verify old content is gone
        history = self.persistence.get_file_history(self.test_file)
        self.assertEqual(len(history), 1)
        self.assertEqual(history[0]["content"], "Test content")

class TestSecurity(unittest.TestCase):
    def setUp(self):
        self.security = SecurityManager("test-api-key")
    
    def test_verify_api_key(self):
        """Test API key verification"""
        self.assertTrue(self.security.verify_api_key("test-api-key"))
        self.assertFalse(self.security.verify_api_key("wrong-key"))
    
    def test_create_and_verify_token(self):
        """Test token creation and verification"""
        # Create token
        token, expires = self.security.create_token({"sub": "test"})
        
        # Verify token
        token_data = self.security.verify_token(token)
        
        self.assertIsNotNone(token_data)
        self.assertEqual(token_data["sub"], "test")
    
    def test_rate_limiting(self):
        """Test rate limiting"""
        # Should allow requests within limit
        for i in range(10):
            self.assertTrue(self.security.check_rate_limit("127.0.0.1", "auth"))
        
        # Should block requests over limit
        self.assertFalse(self.security.check_rate_limit("127.0.0.1", "auth"))
    
    def test_ip_blocking(self):
        """Test IP blocking"""
        # Block IP
        self.security.block_ip("192.168.1.1", 3600)
        
        # Should be blocked
        self.assertFalse(self.security.check_rate_limit("192.168.1.1"))

class TestOptimizations(unittest.TestCase):
    def setUp(self):
        # Create a temporary directory for test files
        self.test_dir = tempfile.mkdtemp()
        
        # Create some test files
        self.test_files = []
        for i in range(5):
            file_path = os.path.join(self.test_dir, f"test_file_{i}.txt")
            with open(file_path, "w") as f:
                f.write(f"Content {i}")
            self.test_files.append(file_path)
    
    def tearDown(self):
        # Clean up temporary directory
        shutil.rmtree(self.test_dir)
    
    def test_file_indexer(self):
        """Test file indexer"""
        indexer = FileIndexer()
        
        # Scan directory
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        try:
            # Run scan
            result = loop.run_until_complete(indexer.scan_directory(self.test_dir))
            
            # Should have found all files
            self.assertEqual(len(result), 5)
            
            # Check file info
            for file_path in self.test_files:
                self.assertIn(file_path, result)
                self.assertIn("content", result[file_path])
                self.assertIn("content_hash", result[file_path])
        finally:
            loop.close()
    
    def test_connection_manager(self):
        """Test connection manager"""
        manager = ConnectionManager()
        
        # Create mock connections
        conn1 = MagicMock()
        conn2 = MagicMock()
        
        # Add connections
        manager.add_connection(conn1, {"client_id": "client1"})
        manager.add_connection(conn2, {"client_id": "client2"})
        
        # Should have two connections
        self.assertEqual(len(manager.active_connections), 2)
        
        # Get stats
        stats = manager.get_connection_stats()
        self.assertEqual(stats["total_connections"], 2)
        self.assertEqual(stats["connection_info"]["client1"], 1)
        self.assertEqual(stats["connection_info"]["client2"], 1)
        
        # Remove connection
        manager.remove_connection(conn1)
        self.assertEqual(len(manager.active_connections), 1)

class TestIntegration(unittest.TestCase):
    """Integration tests for the entire system"""
    
    @classmethod
    def setUpClass(cls):
        # Start server in a separate process
        cls.server_process = subprocess.Popen(
            [sys.executable, "server.py"],
            env={**os.environ, "WATCH_PATH": tempfile.mkdtemp(), "MCP_API_KEY": "test-key"},
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        # Wait for server to start
        time.sleep(2)
    
    @classmethod
    def tearDownClass(cls):
        # Stop server
        cls.server_process.send_signal(signal.SIGTERM)
        cls.server_process.wait()
    
    def test_server_running(self):
        """Test that server is running"""
        try:
            response = requests.get("http://localhost:8000/")
            self.assertEqual(response.status_code, 200)
        except requests.exceptions.ConnectionError:
            self.fail("Server is not running")
    
    def test_authentication(self):
        """Test authentication"""
        # Valid API key
        response = requests.post(
            "http://localhost:8000/auth",
            json={"api_key": "test-key"}
        )
        self.assertEqual(response.status_code, 200)
        self.assertIn("token", response.json())
        
        # Invalid API key
        response = requests.post(
            "http://localhost:8000/auth",
            json={"api_key": "wrong-key"}
        )
        self.assertEqual(response.status_code, 401)
    
    def test_file_monitoring(self):
        """Test file monitoring"""
        # Create a test file in the monitored directory
        watch_path = os.environ.get("WATCH_PATH", tempfile.gettempdir())
        test_file = os.path.join(watch_path, "integration_test.txt")
        
        with open(test_file, "w") as f:
            f.write("Integration test content")
        
        # Wait for file to be detected
        time.sleep(1)
        
        # Get file list
        response = requests.get(
            "http://localhost:8000/api/files",
            headers={"X-API-Key": "test-key"}
        )
        
        self.assertEqual(response.status_code, 200)
        
        # File should be in the list
        files = response.json()["files"]
        file_paths = [f["path"] for f in files]
        self.assertIn(test_file, file_paths)
        
        # Clean up
        os.unlink(test_file)

def run_all_tests():
    """Run all tests"""
    # Create test suite
    suite = unittest.TestSuite()
    
    # Add test cases
    suite.addTest(unittest.makeSuite(TestFileConversation))
    suite.addTest(unittest.makeSuite(TestPersistence))
    suite.addTest(unittest.makeSuite(TestSecurity))
    suite.addTest(unittest.makeSuite(TestOptimizations))
    
    # Run integration tests only if server is not already running
    try:
        requests.get("http://localhost:8000/")
        logger.warning("Server already running, skipping integration tests")
    except requests.exceptions.ConnectionError:
        suite.addTest(unittest.makeSuite(TestIntegration))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    return result.wasSuccessful()

if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)

