#!/usr/bin/env python3
import os
import sys
import subprocess
import argparse
import json
import logging
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("file-monitor-mcp-setup")

def check_python_version():
    """Check if Python version is 3.7+"""
    if sys.version_info < (3, 7):
        logger.error("Python 3.7 or higher is required")
        sys.exit(1)

def install_dependencies():
    """Install required dependencies"""
    dependencies = [
        "fastapi",
        "uvicorn",
        "websockets",
        "watchdog",
        "aiohttp",
        "pydantic",
        "rich"
    ]
    
    logger.info("Installing dependencies...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install"] + dependencies)
        logger.info("Dependencies installed successfully")
    except subprocess.CalledProcessError as e:
        logger.error(f"Failed to install dependencies: {e}")
        sys.exit(1)

def create_config_file(config):
    """Create configuration file"""
    config_dir = Path.home() / ".file-monitor-mcp"
    config_dir.mkdir(exist_ok=True)
    
    config_file = config_dir / "config.json"
    
    # Default configuration
    default_config = {
        "watch_path": ".",
        "api_key": "dev-api-key-change-me-in-production",
        "file_patterns": [],
        "max_file_size": 1024 * 1024,  # 1MB
        "email_config": None,
        "webhook_url": None,
        "notification_rules": []
    }
    
    # Update with provided config
    if config:
        default_config.update(config)
    
    # Write config file
    with open(config_file, "w") as f:
        json.dump(default_config, f, indent=2)
    
    logger.info(f"Configuration file created at {config_file}")
    return config_file

def create_systemd_service(config_file):
    """Create systemd service file for auto-start"""
    service_content = f"""[Unit]
Description=File Monitor MCP Server
After=network.target

[Service]
ExecStart={sys.executable} {os.path.abspath("server.py")}
WorkingDirectory={os.path.abspath(".")}
Environment="CONFIG_FILE={config_file}"
Restart=always
User={os.getlogin()}

[Install]
WantedBy=multi-user.target
"""
    
    service_file = Path.home() / ".config" / "systemd" / "user" / "file-monitor-mcp.service"
    service_file.parent.mkdir(parents=True, exist_ok=True)
    
    with open(service_file, "w") as f:
        f.write(service_content)
    
    logger.info(f"Systemd service file created at {service_file}")
    logger.info("To enable the service, run:")
    logger.info(f"  systemctl --user enable {service_file.name}")
    logger.info(f"  systemctl --user start {service_file.name}")

def main():
    parser = argparse.ArgumentParser(description="File Monitor MCP Setup")
    parser.add_argument("--watch-path", help="Directory to monitor")
    parser.add_argument("--api-key", help="API key for authentication")
    parser.add_argument("--file-patterns", help="Comma-separated list of file patterns")
    parser.add_argument("--max-file-size", type=int, help="Maximum file size in bytes")
    parser.add_argument("--systemd", action="store_true", help="Create systemd service file")
    parser.add_argument("--skip-deps", action="store_true", help="Skip dependency installation")
    
    args = parser.parse_args()
    
    # Check Python version
    check_python_version()
    
    # Install dependencies
    if not args.skip_deps:
        install_dependencies()
    
    # Create config
    config = {}
    if args.watch_path:
        config["watch_path"] = args.watch_path
    if args.api_key:
        config["api_key"] = args.api_key
    if args.file_patterns:
        config["file_patterns"] = [p.strip() for p in args.file_patterns.split(",")]
    if args.max_file_size:
        config["max_file_size"] = args.max_file_size
    
    config_file = create_config_file(config)
    
    # Create systemd service
    if args.systemd:
        create_systemd_service(config_file)
    
    logger.info("Setup completed successfully")
    logger.info("To start the server, run:")
    logger.info("  python server.py")

if __name__ == "__main__":
    main()

