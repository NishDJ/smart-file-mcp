#!/usr/bin/env python3
import os
import logging
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("file-monitor-mcp.web_ui")

class WebUI:
    """Web UI for the File Monitor MCP"""
    def __init__(self, app: FastAPI, server_name: str, version: str):
        self.app = app
        self.server_name = server_name
        self.version = version
        
        # Set up templates and static files
        self.templates = Jinja2Templates(directory="templates")
        self.app.mount("/static", StaticFiles(directory="static"), name="static")
        
        # Register routes
        self.register_routes()
    
    def register_routes(self):
        """Register web UI routes"""
        @self.app.get("/", response_class=HTMLResponse)
        async def get_index(request: Request):
            """Serve the index page"""
            return self.templates.TemplateResponse(
                "index.html",
                {
                    "request": request,
                    "server_name": self.server_name,
                    "version": self.version
                }
            )
        
        logger.info("Web UI routes registered")

