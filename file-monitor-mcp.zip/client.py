import asyncio
import json
import argparse
import os
import time
import sys
import websockets
import aiohttp
import uuid
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.syntax import Syntax
from rich.live import Live
from rich.layout import Layout
from rich.text import Text
from rich.progress import Progress, SpinnerColumn, TextColumn

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("client.log")
    ]
)
logger = logging.getLogger("file-monitor-mcp-client")

# Rich console for pretty output
console = Console()

class FileMonitorClient:
    def __init__(self, server_url: str, api_key: str):
        self.server_url = server_url
        self.api_key = api_key
        self.token = None
        self.token_expires = None
        self.ws = None
        self.session = None
        self.connected = False
        self.server_capabilities = []
    
    async def authenticate(self):
        """Authenticate with the server and get a token"""
        try:
            if not self.session:
                self.session = aiohttp.ClientSession()
            
            async with self.session.post(
                f"{self.server_url}/auth",
                json={"api_key": self.api_key},
                headers={"Content-Type": "application/json"}
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise Exception(f"Authentication failed: {error_text}")
                
                data = await response.json()
                self.token = data["token"]
                self.token_expires = datetime.fromisoformat(data["expires"].replace('Z', '+00:00'))
                
                console.print(f"[green]Authenticated successfully. Token expires at {self.token_expires}[/green]")
                return True
        except Exception as e:
            console.print(f"[red]Authentication error: {e}[/red]")
            return False
    
    async def connect(self):
        """Connect to the server via WebSocket"""
        try:
            if not self.token and not await self.authenticate():
                return False
            
            self.ws = await websockets.connect(f"{self.server_url.replace('http', 'ws')}/mcp")
            
            # Send authentication
            await self.ws.send(json.dumps({"token": self.token}))
            
            # Wait for init response
            response = await self.ws.recv()
            data = json.loads(response)
            
            if "error" in data:
                raise Exception(f"Connection error: {data['error']}")
            
            if data.get("type") == "init_response":
                self.connected = True
                self.server_capabilities = data.get("capabilities", [])
                console.print(f"[green]Connected to {data.get('name')} v{data.get('version')}[/green]")
                console.print(f"[green]Server capabilities: {', '.join(self.server_capabilities)}[/green]")
                return True
            else:
                raise Exception(f"Unexpected response: {data}")
        except Exception as e:
            console.print(f"[red]Connection error: {e}[/red]")
            return False
    
    async def disconnect(self):
        """Disconnect from the server"""
        if self.ws:
            await self.ws.close()
            self.ws = None
            self.connected = False
        
        if self.session:
            await self.session.close()
            self.session = None
    
    async def send_query(self, query_type: str, file_path: Optional[str] = None, 
                        details: Optional[Dict] = None, filters: Optional[Dict] = None) -> Dict:
        """Send a query to the server"""
        if not self.connected and not await self.connect():
            raise Exception("Not connected to server")
        
        query_id = str(uuid.uuid4())
        query = {
            "type": "query",
            "id": query_id,
            "query": {
                "query_type": query_type
            }
        }
        
        if file_path:
            query["query"]["file_path"] = file_path
        
        if details:
            query["query"]["details"] = details
        
        if filters:
            query["query"]["filters"] = filters
        
        await self.ws.send(json.dumps(query))
        
        response = await self.ws.recv()
        data = json.loads(response)
        
        if data.get("type") != "query_response" or data.get("id") != query_id:
            raise Exception(f"Unexpected response: {data}")
        
        return data.get("response", {})
    
    async def http_request(self, endpoint: str, method: str = "GET", 
                          data: Optional[Dict] = None) -> Dict:
        """Send an HTTP request to the server"""
        if not self.session:
            self.session = aiohttp.ClientSession()
        
        headers = {
            "Content-Type": "application/json",
            "X-API-Key": self.api_key
        }
        
        try:
            if method == "GET":
                async with self.session.get(
                    f"{self.server_url}{endpoint}",
                    headers=headers
                ) as response:
                    if response.status != 200:
                        error_text = await response.text()
                        raise Exception(f"Request failed: {error_text}")
                    
                    return await response.json()
            elif method == "POST":
                async with self.session.post(
                    f"{self.server_url}{endpoint}",
                    json=data,
                    headers=headers
                ) as response:
                    if response.status != 200:
                        error_text = await response.text()
                        raise Exception(f"Request failed: {error_text}")
                    
                    return await response.json()
            else:
                raise Exception(f"Unsupported method: {method}")
        except Exception as e:
            console.print(f"[red]HTTP request error: {e}[/red]")
            return {"error": str(e)}
    
    async def list_files(self, filters: Optional[Dict] = None):
        """List all monitored files"""
        with console.status("[bold green]Fetching file list..."):
            response = await self.send_query("get_all_files", filters=filters)
        
        if "error" in response:
            console.print(f"[red]Error: {response['error']}[/red]")
            return
        
        files = response.get("files", [])
        
        if not files:
            console.print("[yellow]No files found.[/yellow]")
            return
        
        table = Table(title=f"Monitored Files ({len(files)})")
        table.add_column("File Path", style="cyan")
        table.add_column("Last Modified", style="green")
        table.add_column("Messages", style="magenta")
        
        for file in sorted(files, key=lambda x: x["path"]):
            last_modified = datetime.fromtimestamp(file["last_modified"]).strftime("%Y-%m-%d %H:%M:%S")
            table.add_row(
                file["path"],
                last_modified,
                str(file["message_count"])
            )
        
        console.print(table)
    
    async def get_file_history(self, file_path: str, limit: Optional[int] = None):
        """Get conversation history for a file"""
        filters = {}
        if limit:
            filters["limit"] = limit
        
        with console.status(f"[bold green]Fetching history for {file_path}..."):
            response = await self.send_query("get_file_history", file_path=file_path, filters=filters)
        
        if "error" in response:
            console.print(f"[red]Error: {response['error']}[/red]")
            return
        
        messages = response.get("messages", [])
        
        if not messages:
            console.print("[yellow]No messages found for this file.[/yellow]")
            return
        
        console.print(Panel(
            f"[bold]File: [cyan]{response['file_path']}[/cyan][/bold]\n"
            f"Last Modified: {datetime.fromtimestamp(response['last_modified']).strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"Message Count: {response['message_count']}",
            title="File Information"
        ))
        
        for i, msg in enumerate(messages):
            timestamp = datetime.fromtimestamp(msg["timestamp"]).strftime("%Y-%m-%d %H:%M:%S")
            role_color = "green" if msg["role"] == "assistant" else "blue" if msg["role"] == "system" else "yellow"
            
            console.print(f"[{role_color}]{msg['role']}[/{role_color}] ({timestamp}):")
            
            # Format message content
            content = msg["content"]
            if "```diff" in content:
                # Extract and format diff blocks
                parts = content.split("```diff")
                console.print(parts[0])
                for part in parts[1:]:
                    if "```" in part:
                        diff_content, rest = part.split("```", 1)
                        console.print(Syntax(diff_content, "diff", theme="monokai"))
                        console.print(rest)
                    else:
                        console.print(part)
            else:
                console.print(content)
            
            console.print("---")
        
        # Show file content if available
        if response.get("content"):
            console.print(Panel(
                Syntax(response["content"], "text", theme="monokai", line_numbers=True),
                title="File Content"
            ))
        
        # Show diff if available
        if response.get("diff") and response["diff"] != "No diff available":
            console.print(Panel(
                Syntax(response["diff"], "diff", theme="monokai"),
                title="Latest Changes"
            ))
    
    async def get_recent_changes(self, filters: Optional[Dict] = None, limit: int = 10):
        """Get recent changes for all files"""
        details = {"limit": limit, "sort": "timestamp"}
        
        with console.status("[bold green]Fetching recent changes..."):
            response = await self.send_query("get_recent_changes", details=details, filters=filters)
        
        if "error" in response:
            console.print(f"[red]Error: {response['error']}[/red]")
            return
        
        changes = response.get("recent_changes", {})
        
        if not changes:
            console.print("[yellow]No recent changes found.[/yellow]")
            return
        
        table = Table(title=f"Recent Changes ({len(changes)})")
        table.add_column("File Path", style="cyan")
        table.add_column("Last Change", style="green")
        table.add_column("Role", style="magenta")
        table.add_column("Content", style="white")
        
        for file_path, message in changes.items():
            timestamp = datetime.fromtimestamp(message["timestamp"]).strftime("%Y-%m-%d %H:%M:%S")
            content = message["content"]
            if len(content) > 50:
                content = content[:47] + "..."
            
            table.add_row(
                file_path,
                timestamp,
                message["role"],
                content
            )
        
        console.print(table)
    
    async def get_file_diff(self, file_path: str):
        """Get diff for a file"""
        with console.status(f"[bold green]Fetching diff for {file_path}..."):
            response = await self.send_query("get_file_diff", file_path=file_path)
        
        if "error" in response:
            console.print(f"[red]Error: {response['error']}[/red]")
            return
        
        diff = response.get("diff")
        
        if not diff or diff == "No diff available":
            console.print("[yellow]No diff available for this file.[/yellow]")
            return
        
        console.print(Panel(
            Syntax(diff, "diff", theme="monokai"),
            title=f"Diff for {file_path}"
        ))
    
    async def get_server_stats(self):
        """Get server statistics"""
        with console.status("[bold green]Fetching server statistics..."):
            response = await self.send_query("get_server_stats")
        
        if "error" in response:
            console.print(f"[red]Error: {response['error']}[/red]")
            return
        
        uptime = format_duration(response.get("uptime", 0))
        
        console.print(Panel(
            f"[bold]Uptime:[/bold] {uptime}\n"
            f"[bold]File Count:[/bold] {response.get('file_count', 0)}\n"
            f"[bold]Client Count:[/bold] {response.get('client_count', 0)}\n"
            f"[bold]Watch Path:[/bold] {response.get('watch_path', 'Unknown')}\n"
            f"[bold]File Patterns:[/bold] {', '.join(response.get('file_patterns', ['All files']))}\n"
            f"[bold]Max File Size:[/bold] {format_bytes(response.get('max_file_size', 0))}",
            title="Server Statistics"
        ))
    
    async def get_analytics(self):
        """Get analytics data"""
        with console.status("[bold green]Fetching analytics data..."):
            response = await self.send_query("get_analytics")
        
        if "error" in response:
            console.print(f"[red]Error: {response['error']}[/red]")
            return
        
        # Display event counts
        event_counts = response.get("event_counts", {})
        if event_counts:
            table = Table(title="Event Counts")
            table.add_column("Event Type", style="cyan")
            table.add_column("Count", style="green")
            
            for event_type, count in event_counts.items():
                table.add_row(event_type, str(count))
            
            console.print(table)
        
        # Display file type distribution
        file_types = response.get("file_type_distribution", {})
        if file_types:
            table = Table(title="File Type Distribution")
            table.add_column("File Type", style="cyan")
            table.add_column("Count", style="green")
            
            for file_type, count in file_types.items():
                table.add_row(file_type, str(count))
            
            console.print(table)
        
        # Display most active files
        active_files = response.get("most_active_files", {})
        if active_files:
            table = Table(title="Most Active Files")
            table.add_column("File Path", style="cyan")
            table.add_column("Change Count", style="green")
            
            for file_path, count in active_files.items():
                table.add_row(file_path, str(count))
            
            console.print(table)
    
    async def configure_server(self, watch_path: Optional[str] = None, 
                              file_patterns: Optional[List[str]] = None,
                              max_file_size: Optional[int] = None):
        """Configure the server"""
        config = {}
        
        if watch_path:
            config["watch_path"] = watch_path
        
        if file_patterns:
            config["file_patterns"] = file_patterns
        
        if max_file_size:
            config["max_file_size"] = max_file_size
        
        with console.status("[bold green]Configuring server..."):
            response = await self.http_request("/config", method="POST", data=config)
        
        if "error" in response:
            console.print(f"[red]Error: {response['error']}[/red]")
            return
        
        console.print("[green]Server configured successfully.[/green]")
        console.print(Panel(
            f"[bold]Watch Path:[/bold] {response['config']['watch_path']}\n"
            f"[bold]File Patterns:[/bold] {', '.join(response['config']['file_patterns']) if response['config']['file_patterns'] else 'All files'}\n"
            f"[bold]Max File Size:[/bold] {format_bytes(response['config']['max_file_size'])}",
            title="Server Configuration"
        ))
    
    async def configure_notifications(self, email_config: Optional[Dict] = None,
                                     webhook_url: Optional[str] = None,
                                     rule: Optional[Dict] = None):
        """Configure notifications"""
        config = {}
        
        if email_config:
            config["email"] = email_config
        
        if webhook_url:
            config["webhook_url"] = webhook_url
        
        if rule:
            config["rule"] = rule
        
        with console.status("[bold green]Configuring notifications..."):
            response = await self.http_request("/notifications/config", method="POST", data=config)
        
        if "error" in response:
            console.print(f"[red]Error: {response['error']}[/red]")
            return
        
        console.print("[green]Notifications configured successfully.[/green]")
    
    async def monitor_changes(self):
        """Monitor file changes in real-time"""
        if not self.connected and not await self.connect():
            return
        
        console.print("[green]Monitoring file changes. Press Ctrl+C to stop.[/green]")
        
        try:
            layout = Layout()
            layout.split(
                Layout(name="header", size=3),
                Layout(name="body")
            )
            
            header = Text("File Monitor MCP - Real-time Changes", style="bold")
            header.append("\nPress Ctrl+C to stop monitoring", style="italic")
            
            layout["header"].update(Panel(header))
            layout["body"].update(Text("Waiting for changes..."))
            
            with Live(layout, refresh_per_second=4):
                while True:
                    try:
                        response = await asyncio.wait_for(self.ws.recv(), timeout=1.0)
                        data = json.loads(response)
                        
                        if "file_path" in data and "event_type" in data:
                            timestamp = datetime.fromtimestamp(data["timestamp"]).strftime("%Y-%m-%d %H:%M:%S")
                            
                            text = Text()
                            text.append(f"[{timestamp}] ", style="dim")
                            text.append(f"{data['event_type'].upper()}: ", style="bold magenta")
                            text.append(data['file_path'], style="cyan")
                            
                            if "message" in data:
                                text.append("\n  Message: ", style="bold")
                                text.append(data["message"]["content"].split("\n")[0])
                            
                            if "content_changed" in data and data["content_changed"]:
                                text.append("\n  Content changed", style="green")
                            
                            if "diff" in data and data["diff"]:
                                text.append("\n  Diff available", style="blue")
                            
                            text.append("\n" + "-" * 80 + "\n")
                            
                            current = layout["body"].renderable
                            if isinstance(current, Text):
                                if "Waiting for changes..." in current.plain:
                                    layout["body"].update(text)
                                else:
                                    new_text = Text.from_markup(text.markup)
                                    new_text.append(current)
                                    layout["body"].update(new_text)
                    except asyncio.TimeoutError:
                        pass
        except KeyboardInterrupt:
            console.print("[yellow]Monitoring stopped.[/yellow]")
        except Exception as e:
            console.print(f"[red]Error during monitoring: {e}[/red]")

def format_bytes(size: int) -> str:
    """Format bytes to human-readable format"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size < 1024.0:
            return f"{size:.2f} {unit}"
        size /= 1024.0
    return f"{size:.2f} PB"

def format_duration(seconds: float) -> str:
    """Format duration in seconds to human-readable format"""
    days, remainder = divmod(int(seconds), 86400)
    hours, remainder = divmod(remainder, 3600)
    minutes, seconds = divmod(remainder, 60)
    
    parts = []
    if days > 0:
        parts.append(f"{days}d")
    if hours > 0:
        parts.append(f"{hours}h")
    if minutes > 0:
        parts.append(f"{minutes}m")
    parts.append(f"{seconds}s")
    
    return " ".join(parts)

async def main():
    parser = argparse.ArgumentParser(description="File Monitor MCP Client")
    parser.add_argument("--server", default="http://localhost:8000", help="Server URL")
    parser.add_argument("--api-key", default=os.environ.get("MCP_API_KEY", "dev-api-key-change-me-in-production"), help="API key")
    parser.add_argument("--command", required=True, choices=[
        "list", "history", "recent", "diff", "stats", "analytics", 
        "configure", "monitor", "notify"
    ], help="Command to execute")
    parser.add_argument("--file", help="File path for history or diff commands")
    parser.add_argument("--limit", type=int, help="Limit for history or recent commands")
    parser.add_argument("--filter", action="append", help="Filters in format key=value")
    parser.add_argument("--watch-path", help="Watch path for configure command")
    parser.add_argument("--patterns", help="File patterns for configure command (comma-separated)")
    parser.add_argument("--max-size", type=int, help="Max file size for configure command")
    parser.add_argument("--webhook", help="Webhook URL for notify command")
    parser.add_argument("--rule-type", choices=["all_events", "specific_event", "path_pattern", "content_change"], help="Notification rule type")
    parser.add_argument("--rule-details", help="Notification rule details in JSON format")
    
    args = parser.parse_args()
    
    client = FileMonitorClient(args.server, args.api_key)
    
    try:
        # Parse filters
        filters = {}
        if args.filter:
            for f in args.filter:
                key, value = f.split("=", 1)
                # Try to convert to number if possible
                try:
                    if "." in value:
                        filters[key] = float(value)
                    else:
                        filters[key] = int(value)
                except ValueError:
                    filters[key] = value
        
        if args.command == "list":
            await client.list_files(filters)
        
        elif args.command == "history":
            if not args.file:
                console.print("[red]Error: --file is required for history command[/red]")
                return
            await client.get_file_history(args.file, args.limit)
        
        elif args.command == "recent":
            await client.get_recent_changes(filters, args.limit or 10)
        
        elif args.command == "diff":
            if not args.file:
                console.print("[red]Error: --file is required for diff command[/red]")
                return
            await client.get_file_diff(args.file)
        
        elif args.command == "stats":
            await client.get_server_stats()
        
        elif args.command == "analytics":
            await client.get_analytics()
        
        elif args.command == "configure":
            file_patterns = args.patterns.split(",") if args.patterns else None
            await client.configure_server(args.watch_path, file_patterns, args.max_size)
        
        elif args.command == "monitor":
            await client.monitor_changes()
        
        elif args.command == "notify":
            rule = None
            if args.rule_type:
                rule = {"type": args.rule_type}
                if args.rule_details:
                    try:
                        details = json.loads(args.rule_details)
                        rule.update(details)
                    except json.JSONDecodeError:
                        console.print("[red]Error: rule-details must be valid JSON[/red]")
                        return
            
            await client.configure_notifications(webhook_url=args.webhook, rule=rule)
    
    finally:
        await client.disconnect()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        console.print("[yellow]Operation cancelled.[/yellow]")
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)

