#!/usr/bin/env python3
import os
import time
import sqlite3
import json
import logging
import threading
from typing import Dict, List, Optional, Any, Tuple

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("file-monitor-mcp.persistence")

class PersistenceManager:
    """Manages persistence of file history and conversations"""
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.connection_lock = threading.Lock()
        
        # Initialize database
        self._init_db()
    
    def _get_connection(self) -> sqlite3.Connection:
        """Get a database connection"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    def _init_db(self):
        """Initialize the database schema"""
        with self.connection_lock:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            # Create files table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS files (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    path TEXT UNIQUE,
                    created_at REAL
                )
            ''')
            
            # Create messages table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    file_id INTEGER,
                    role TEXT,
                    content TEXT,
                    timestamp REAL,
                    message_id TEXT,
                    FOREIGN KEY (file_id) REFERENCES files (id)
                )
            ''')
            
            # Create file_contents table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS file_contents (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    file_id INTEGER,
                    content TEXT,
                    content_hash TEXT,
                    timestamp REAL,
                    FOREIGN KEY (file_id) REFERENCES files (id)
                )
            ''')
            
            # Create events table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    file_id INTEGER,
                    event_type TEXT,
                    timestamp REAL,
                    details TEXT,
                    FOREIGN KEY (file_id) REFERENCES files (id)
                )
            ''')
            
            # Create indexes
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_files_path ON files (path)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_messages_file_id ON messages (file_id)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_messages_timestamp ON messages (timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_file_contents_file_id ON file_contents (file_id)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_file_contents_timestamp ON file_contents (timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_events_file_id ON events (file_id)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_events_timestamp ON events (timestamp)')
            
            conn.commit()
            conn.close()
    
    def get_file_id(self, file_path: str) -> int:
        """Get or create a file ID"""
        with self.connection_lock:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            # Check if file exists
            cursor.execute('SELECT id FROM files WHERE path = ?', (file_path,))
            row = cursor.fetchone()
            
            if row:
                file_id = row['id']
            else:
                # Create new file
                cursor.execute(
                    'INSERT INTO files (path, created_at) VALUES (?, ?)',
                    (file_path, time.time())
                )
                file_id = cursor.lastrowid
                conn.commit()
            
            conn.close()
            return file_id
    
    def save_message(self, file_path: str, message: Dict[str, Any]) -> bool:
        """Save a message to the database"""
        try:
            file_id = self.get_file_id(file_path)
            
            with self.connection_lock:
                conn = self._get_connection()
                cursor = conn.cursor()
                
                cursor.execute(
                    'INSERT INTO messages (file_id, role, content, timestamp, message_id) VALUES (?, ?, ?, ?, ?)',
                    (
                        file_id,
                        message['role'],
                        message['content'],
                        message['timestamp'],
                        message['id']
                    )
                )
                
                conn.commit()
                conn.close()
                
                return True
        except Exception as e:
            logger.error(f"Error saving message: {e}")
            return False
    
    def get_messages(self, file_path: str, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """Get messages for a file"""
        try:
            file_id = self.get_file_id(file_path)
            
            with self.connection_lock:
                conn = self._get_connection()
                cursor = conn.cursor()
                
                if limit:
                    cursor.execute(
                        'SELECT * FROM messages WHERE file_id = ? ORDER BY timestamp DESC LIMIT ?',
                        (file_id, limit)
                    )
                else:
                    cursor.execute(
                        'SELECT * FROM messages WHERE file_id = ? ORDER BY timestamp ASC',
                        (file_id,)
                    )
                
                rows = cursor.fetchall()
                conn.close()
                
                messages = []
                for row in rows:
                    messages.append({
                        'role': row['role'],
                        'content': row['content'],
                        'timestamp': row['timestamp'],
                        'id': row['message_id']
                    })
                
                return messages
        except Exception as e:
            logger.error(f"Error getting messages: {e}")
            return []
    
    def save_file_content(self, file_path: str, content: str, content_hash: str) -> bool:
        """Save file content to the database"""
        try:
            file_id = self.get_file_id(file_path)
            
            with self.connection_lock:
                conn = self._get_connection()
                cursor = conn.cursor()
                
                cursor.execute(
                    'INSERT INTO file_contents (file_id, content, content_hash, timestamp) VALUES (?, ?, ?, ?)',
                    (file_id, content, content_hash, time.time())
                )
                
                conn.commit()
                conn.close()
                
                return True
        except Exception as e:
            logger.error(f"Error saving file content: {e}")
            return False
    
    def get_file_history(self, file_path: str, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """Get content history for a file"""
        try:
            file_id = self.get_file_id(file_path)
            
            with self.connection_lock:
                conn = self._get_connection()
                cursor = conn.cursor()
                
                if limit:
                    cursor.execute(
                        'SELECT * FROM file_contents WHERE file_id = ? ORDER BY timestamp DESC LIMIT ?',
                        (file_id, limit)
                    )
                else:
                    cursor.execute(
                        'SELECT * FROM file_contents WHERE file_id = ? ORDER BY timestamp DESC',
                        (file_id,)
                    )
                
                rows = cursor.fetchall()
                conn.close()
                
                history = []
                for row in rows:
                    history.append({
                        'content': row['content'],
                        'content_hash': row['content_hash'],
                        'timestamp': row['timestamp']
                    })
                
                return history
        except Exception as e:
            logger.error(f"Error getting file history: {e}")
            return []
    
    def save_event(self, file_path: str, event_type: str, details: Optional[Dict[str, Any]] = None) -> bool:
        """Save an event to the database"""
        try:
            file_id = self.get_file_id(file_path)
            
            with self.connection_lock:
                conn = self._get_connection()
                cursor = conn.cursor()
                
                cursor.execute(
                    'INSERT INTO events (file_id, event_type, timestamp, details) VALUES (?, ?, ?, ?)',
                    (
                        file_id,
                        event_type,
                        time.time(),
                        json.dumps(details) if details else None
                    )
                )
                
                conn.commit()
                conn.close()
                
                return True
        except Exception as e:
            logger.error(f"Error saving event: {e}")
            return False
    
    def get_events(self, file_path: Optional[str] = None, 
                  event_type: Optional[str] = None,
                  limit: Optional[int] = None,
                  start_time: Optional[float] = None,
                  end_time: Optional[float] = None) -> List[Dict[str, Any]]:
        """Get events from the database"""
        try:
            with self.connection_lock:
                conn = self._get_connection()
                cursor = conn.cursor()
                
                query = 'SELECT e.*, f.path FROM events e JOIN files f ON e.file_id = f.id WHERE 1=1'
                params = []
                
                if file_path:
                    file_id = self.get_file_id(file_path)
                    query += ' AND e.file_id = ?'
                    params.append(file_id)
                
                if event_type:
                    query += ' AND e.event_type = ?'
                    params.append(event_type)
                
                if start_time:
                    query += ' AND e.timestamp >= ?'
                    params.append(start_time)
                
                if end_time:
                    query += ' AND e.timestamp <= ?'
                    params.append(end_time)
                
                query += ' ORDER BY e.timestamp DESC'
                
                if limit:
                    query += ' LIMIT ?'
                    params.append(limit)
                
                cursor.execute(query, params)
                rows = cursor.fetchall()
                conn.close()
                
                events = []
                for row in rows:
                    events.append({
                        'file_path': row['path'],
                        'event_type': row['event_type'],
                        'timestamp': row['timestamp'],
                        'details': json.loads(row['details']) if row['details'] else None
                    })
                
                return events
        except Exception as e:
            logger.error(f"Error getting events: {e}")
            return []
    
    def get_all_files(self) -> List[Dict[str, Any]]:
        """Get all files from the database"""
        try:
            with self.connection_lock:
                conn = self._get_connection()
                cursor = conn.cursor()
                
                cursor.execute('''
                    SELECT f.id, f.path, f.created_at, 
                           COUNT(m.id) as message_count,
                           MAX(fc.timestamp) as last_modified
                    FROM files f
                    LEFT JOIN messages m ON f.id = m.file_id
                    LEFT JOIN file_contents fc ON f.id = fc.file_id
                    GROUP BY f.id
                    ORDER BY last_modified DESC
                ''')
                
                rows = cursor.fetchall()
                conn.close()
                
                files = []
                for row in rows:
                    files.append({
                        'path': row['path'],
                        'created_at': row['created_at'],
                        'message_count': row['message_count'],
                        'last_modified': row['last_modified'] or row['created_at']
                    })
                
                return files
        except Exception as e:
            logger.error(f"Error getting all files: {e}")
            return []
    
    def get_file_stats(self, file_path: str) -> Dict[str, Any]:
        """Get statistics for a file"""
        try:
            file_id = self.get_file_id(file_path)
            
            with self.connection_lock:
                conn = self._get_connection()
                cursor = conn.cursor()
                
                # Get message count
                cursor.execute('SELECT COUNT(*) as count FROM messages WHERE file_id = ?', (file_id,))
                message_count = cursor.fetchone()['count']
                
                # Get content count
                cursor.execute('SELECT COUNT(*) as count FROM file_contents WHERE file_id = ?', (file_id,))
                content_count = cursor.fetchone()['count']
                
                # Get event count
                cursor.execute('SELECT COUNT(*) as count FROM events WHERE file_id = ?', (file_id,))
                event_count = cursor.fetchone()['count']
                
                # Get last modified
                cursor.execute('SELECT MAX(timestamp) as last_modified FROM file_contents WHERE file_id = ?', (file_id,))
                last_modified = cursor.fetchone()['last_modified']
                
                # Get created at
                cursor.execute('SELECT created_at FROM files WHERE id = ?', (file_id,))
                created_at = cursor.fetchone()['created_at']
                
                conn.close()
                
                return {
                    'path': file_path,
                    'message_count': message_count,
                    'content_count': content_count,
                    'event_count': event_count,
                    'last_modified': last_modified,
                    'created_at': created_at
                }
        except Exception as e:
            logger.error(f"Error getting file stats: {e}")
            return {
                'path': file_path,
                'message_count': 0,
                'content_count': 0,
                'event_count': 0,
                'last_modified': None,
                'created_at': None
            }
    
    def cleanup_old_data(self, max_age_days: int = 30) -> int:
        """Clean up old data from the database"""
        try:
            max_age = time.time() - (max_age_days * 24 * 60 * 60)
            
            with self.connection_lock:
                conn = self._get_connection()
                cursor = conn.cursor()
                
                # Delete old file contents
                cursor.execute('DELETE FROM file_contents WHERE timestamp < ?', (max_age,))
                content_count = cursor.rowcount
                
                # Delete old events
                cursor.execute('DELETE FROM events WHERE timestamp < ?', (max_age,))
                event_count = cursor.rowcount
                
                conn.commit()
                conn.close()
                
                return content_count + event_count
        except Exception as e:
            logger.error(f"Error cleaning up old data: {e}")
            return 0
    
    def vacuum_database(self) -> bool:
        """Vacuum the database to reclaim space"""
        try:
            with self.connection_lock:
                conn = self._get_connection()
                cursor = conn.cursor()
                
                cursor.execute('VACUUM')
                
                conn.commit()
                conn.close()
                
                return True
        except Exception as e:
            logger.error(f"Error vacuuming database: {e}")
            return False

