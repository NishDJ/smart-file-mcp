"use client"

import  from "../static/app"

export default function SyntheticV0PageForDeployment() {
  return < />
}