# File Monitor MCP Server

A robust file monitoring system that tracks changes to files, maintains conversation history, and provides real-time notifications and analytics.

## Features

- **Real-time File Monitoring**: Watches directories for file changes and maintains a history of modifications
- **Conversation Tracking**: Stores messages and conversations related to each file
- **Persistence**: SQLite database for storing file history and conversations between server restarts
- **Analytics**: Track file change metrics and visualize activity patterns
- **Web UI**: Browser-based interface for monitoring and visualization
- **Notifications**: Email and webhook notifications for file changes
- **Security**: API key authentication, rate limiting, and token-based access
- **Performance Optimizations**: Efficient handling of large directories
- **Rich Client**: Command-line client with interactive UI
- **Docker Support**: Easy deployment with Docker and Docker Compose

## Installation

### Option 1: Standard Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/file-monitor-mcp.git
   cd file-monitor-mcp

