#!/usr/bin/env python3
import os
import time
import json
import logging
import threading
import smtplib
import requests
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Dict, List, Optional, Any, Tuple
import fnmatch
import re

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("file-monitor-mcp.notifications")

class NotificationRule:
    """Rule for when to send notifications"""
    def __init__(self, rule_type: str, **kwargs):
        self.rule_type = rule_type
        self.kwargs = kwargs
    
    def matches(self, event: Dict[str, Any]) -> bool:
        """Check if an event matches this rule"""
        if self.rule_type == "all_events":
            return True
        
        elif self.rule_type == "specific_event":
            event_type = self.kwargs.get("event_type")
            return event.get("event_type") == event_type
        
        elif self.rule_type == "path_pattern":
            pattern = self.kwargs.get("pattern")
            file_path = event.get("file_path", "")
            return fnmatch.fnmatch(file_path, pattern)
        
        elif self.rule_type == "content_change":
            content_pattern = self.kwargs.get("content_pattern")
            
            # Check if event has content
            if "message" in event and "content" in event["message"]:
                content = event["message"]["content"]
                return re.search(content_pattern, content) is not None
            
            return False
        
        return False
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "type": self.rule_type,
            **self.kwargs
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'NotificationRule':
        """Create from dictionary"""
        rule_type = data.pop("type")
        return cls(rule_type, **data)

class NotificationManager:
    """Manages notifications for file changes"""
    def __init__(self):
        self.email_config = None
        self.webhook_url = None
        self.rules = []
        self.notification_queue = []
        self.queue_lock = threading.Lock()
        self.notification_thread = None
        self.stop_event = threading.Event()
    
    def configure_email(self, config: Dict[str, Any]) -> None:
        """Configure email notifications"""
        self.email_config = config
        logger.info("Email notifications configured")
    
    def configure_webhook(self, webhook_url: str) -> None:
        """Configure webhook notifications"""
        self.webhook_url = webhook_url
        logger.info(f"Webhook notifications configured: {webhook_url}")
    
    def add_rule(self, rule: Dict[str, Any]) -> None:
        """Add a notification rule"""
        self.rules.append(NotificationRule.from_dict(rule))
        logger.info(f"Added notification rule: {rule}")
    
    def clear_rules(self) -> None:
        """Clear all notification rules"""
        self.rules = []
        logger.info("Cleared all notification rules")
    
    def start(self) -> None:
        """Start the notification thread"""
        if self.notification_thread is None or not self.notification_thread.is_alive():
            self.stop_event.clear()
            self.notification_thread = threading.Thread(target=self._notification_worker)
            self.notification_thread.daemon = True
            self.notification_thread.start()
            logger.info("Notification thread started")
    
    def stop(self) -> None:
        """Stop the notification thread"""
        if self.notification_thread and self.notification_thread.is_alive():
            self.stop_event.set()
            self.notification_thread.join(timeout=5.0)
            logger.info("Notification thread stopped")
    
    def send_notification(self, event_type: str, event_data: Dict[str, Any]) -> None:
        """Send a notification for an event"""
        # Create event
        event = {
            "event_type": event_type,
            "timestamp": time.time(),
            **event_data
        }
        
        # Check if any rule matches
        for rule in self.rules:
            if rule.matches(event):
                # Add to queue
                with self.queue_lock:
                    self.notification_queue.append(event)
                
                # Start thread if not running
                self.start()
                
                logger.info(f"Queued notification for event: {event_type}")
                return
    
    def _notification_worker(self) -> None:
        """Worker thread for sending notifications"""
        while not self.stop_event.is_set():
            # Get next notification
            notification = None
            with self.queue_lock:
                if self.notification_queue:
                    notification = self.notification_queue.pop(0)
            
            if notification:
                # Send notification
                self._send_notification(notification)
            
            # Sleep for a bit
            time.sleep(1.0)
    
    def _send_notification(self, event: Dict[str, Any]) -> None:
        """Send a notification"""
        try:
            # Send email if configured
            if self.email_config:
                self._send_email_notification(event)
            
            # Send webhook if 
                self._send_email_notification(event)
            
            # Send webhook if configured
            if self.webhook_url:
                self._send_webhook_notification(event)
        
        except Exception as e:
            logger.error(f"Error sending notification: {e}")
    
    def _send_email_notification(self, event: Dict[str, Any]) -> None:
        """Send an email notification"""
        try:
            # Get email config
            smtp_server = self.email_config.get("smtp_server")
            smtp_port = self.email_config.get("smtp_port", 587)
            smtp_username = self.email_config.get("smtp_username")
            smtp_password = self.email_config.get("smtp_password")
            from_email = self.email_config.get("from_email")
            to_email = self.email_config.get("to_email")
            
            if not all([smtp_server, smtp_username, smtp_password, from_email, to_email]):
                logger.error("Incomplete email configuration")
                return
            
            # Create message
            msg = MIMEMultipart()
            msg['From'] = from_email
            msg['To'] = to_email
            msg['Subject'] = f"File Monitor MCP: {event.get('event_type')} - {event.get('file_path')}"
            
            # Create message body
            body = f"""
File Monitor MCP Notification

Event Type: {event.get('event_type')}
File Path: {event.get('file_path')}
Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(event.get('timestamp')))}

"""
            
            if "content_changed" in event and event["content_changed"]:
                body += "Content Changed: Yes\n"
            
            if "diff" in event and event["diff"]:
                body += f"\nDiff:\n{event['diff']}\n"
            
            if "message" in event:
                body += f"\nMessage:\n{event['message']['content']}\n"
            
            msg.attach(MIMEText(body, 'plain'))
            
            # Send email
            with smtplib.SMTP(smtp_server, smtp_port) as server:
                server.starttls()
                server.login(smtp_username, smtp_password)
                server.send_message(msg)
            
            logger.info(f"Email notification sent to {to_email}")
        
        except Exception as e:
            logger.error(f"Error sending email notification: {e}")
    
    def _send_webhook_notification(self, event: Dict[str, Any]) -> None:
        """Send a webhook notification"""
        try:
            # Create payload
            payload = {
                "event_type": event.get("event_type"),
                "file_path": event.get("file_path"),
                "timestamp": event.get("timestamp"),
                "content_changed": event.get("content_changed", False)
            }
            
            if "diff" in event and event["diff"]:
                payload["diff"] = event["diff"]
            
            if "message" in event:
                payload["message"] = event["message"]
            
            # Send webhook
            response = requests.post(
                self.webhook_url,
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=10.0
            )
            
            if response.status_code >= 200 and response.status_code < 300:
                logger.info(f"Webhook notification sent successfully: {response.status_code}")
            else:
                logger.error(f"Webhook notification failed: {response.status_code} - {response.text}")
        
        except Exception as e:
            logger.error(f"Error sending webhook notification: {e}")
    
    def get_config(self) -> Dict[str, Any]:
        """Get notification configuration"""
        return {
            "email_config": self.email_config,
            "webhook_url": self.webhook_url,
            "rules": [rule.to_dict() for rule in self.rules]
        }

