#!/usr/bin/env python3
import os
import time
import json
import logging
import threading
from typing import Dict, List, Optional, Any, Tuple
from collections import Counter, defaultdict
from datetime import datetime, timedelta

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("file-monitor-mcp.analytics")

class FileAnalytics:
    """Analytics for tracking file changes"""
    def __init__(self, persistence):
        self.persistence = persistence
        self.event_counts = Counter()
        self.file_type_counts = Counter()
        self.file_activity = Counter()
        self.activity_over_time = defaultdict(int)
        self.last_update = time.time()
        self.update_interval = 300  # 5 minutes
        self.lock = threading.Lock()
    
    def track_event(self, event_type: str, file_path: str, details: Optional[Dict[str, Any]] = None) -> None:
        """Track an event"""
        with self.lock:
            # Update event counts
            self.event_counts[event_type] += 1
            
            # Update file type counts
            file_ext = os.path.splitext(file_path)[1].lower()
            if not file_ext:
                file_ext = "no_extension"
            else:
                file_ext = file_ext[1:]  # Remove the dot
            
            self.file_type_counts[file_ext] += 1
            
            # Update file activity
            self.file_activity[file_path] += 1
            
            # Update activity over time
            current_hour = int(time.time() / 3600) * 3600  # Round to hour
            self.activity_over_time[current_hour] += 1
            
            # Save event to persistence
            self.persistence.save_event(file_path, event_type, details)
            
            # Update analytics data if interval has passed
            if time.time() - self.last_update > self.update_interval:
                self._update_analytics()
    
    def _update_analytics(self) -> None:
        """Update analytics data from persistence"""
        try:
            # Get events from the last 30 days
            start_time = time.time() - (30 * 24 * 60 * 60)
            events = self.persistence.get_events(start_time=start_time)
            
            # Reset counters
            self.event_counts = Counter()
            self.file_type_counts = Counter()
            self.file_activity = Counter()
            self.activity_over_time = defaultdict(int)
            
            # Process events
            for event in events:
                # Update event counts
                self.event_counts[event['event_type']] += 1
                
                # Update file type counts
                file_ext = os.path.splitext(event['file_path'])[1].lower()
                if not file_ext:
                    file_ext = "no_extension"
                else:
                    file_ext = file_ext[1:]  # Remove the dot
                
                self.file_type_counts[file_ext] += 1
                
                # Update file activity
                self.file_activity[event['file_path']] += 1
                
                # Update activity over time
                hour = int(event['timestamp'] / 3600) * 3600  # Round to hour
                self.activity_over_time[hour] += 1
            
            self.last_update = time.time()
            logger.info("Analytics data updated")
        except Exception as e:
            logger.error(f"Error updating analytics: {e}")
    
    def get_analytics(self) -> Dict[str, Any]:
        """Get analytics data"""
        with self.lock:
            # Update analytics if needed
            if time.time() - self.last_update > self.update_interval:
                self._update_analytics()
            
            # Get most active files
            most_active_files = dict(self.file_activity.most_common(10))
            
            # Get activity over time for the last 7 days
            now = time.time()
            start_time = now - (7 * 24 * 60 * 60)
            activity_data = {
                ts: count for ts, count in self.activity_over_time.items()
                if ts >= start_time
            }
            
            return {
                "event_counts": dict(self.event_counts),
                "file_type_distribution": dict(self.file_type_counts),
                "most_active_files": most_active_files,
                "activity_over_time": activity_data
            }
    
    def get_file_analytics(self, file_path: str) -> Dict[str, Any]:
        """Get analytics for a specific file"""
        try:
            # Get file stats
            stats = self.persistence.get_file_stats(file_path)
            
            # Get events for this file
            events = self.persistence.get_events(file_path=file_path)
            
            # Count event types
            event_counts = Counter()
            for event in events:
                event_counts[event['event_type']] += 1
            
            # Calculate activity over time
            activity_over_time = defaultdict(int)
            for event in events:
                hour = int(event['timestamp'] / 3600) * 3600  # Round to hour
                activity_over_time[hour] += 1
            
            # Get recent activity
            recent_events = events[:10]
            
            return {
                "stats": stats,
                "event_counts": dict(event_counts),
                "activity_over_time": dict(activity_over_time),
                "recent_events": recent_events
            }
        except Exception as e:
            logger.error(f"Error getting file analytics: {e}")
            return {}
    
    def get_event_timeline(self, start_time: Optional[float] = None, 
                          end_time: Optional[float] = None,
                          interval: str = "hour") -> Dict[str, Any]:
        """Get event timeline"""
        try:
            # Set default time range to last 7 days
            if not end_time:
                end_time = time.time()
            
            if not start_time:
                start_time = end_time - (7 * 24 * 60 * 60)
            
            # Get events in time range
            events = self.persistence.get_events(start_time=start_time, end_time=end_time)
            
            # Group by interval
            timeline = defaultdict(int)
            event_types = defaultdict(lambda: defaultdict(int))
            
            for event in events:
                if interval == "hour":
                    # Group by hour
                    ts = int(event['timestamp'] / 3600) * 3600
                elif interval == "day":
                    # Group by day
                    ts = int(event['timestamp'] / 86400) * 86400
                elif interval == "week":
                    # Group by week (starting from Monday)
                    dt = datetime.fromtimestamp(event['timestamp'])
                    start_of_week = dt - timedelta(days=dt.weekday())
                    start_of_week = start_of_week.replace(hour=0, minute=0, second=0, microsecond=0)
                    ts = int(start_of_week.timestamp())
                else:
                    # Default to hour
                    ts = int(event['timestamp'] / 3600) * 3600
                
                timeline[ts] += 1
                event_types[ts][event['event_type']] += 1
            
            # Convert to list of points
            timeline_points = [
                {"timestamp": ts, "count": count}
                for ts, count in sorted(timeline.items())
            ]
            
            # Convert event types to list
            event_type_points = {}
            for ts, counts in event_types.items():
                for event_type, count in counts.items():
                    if event_type not in event_type_points:
                        event_type_points[event_type] = []
                    
                    event_type_points[event_type].append({
                        "timestamp": ts,
                        "count": count
                    })
            
            # Sort event type points by timestamp
            for event_type in event_type_points:
                event_type_points[event_type].sort(key=lambda x: x["timestamp"])
            
            return {
                "timeline": timeline_points,
                "event_types": event_type_points,
                "start_time": start_time,
                "end_time": end_time,
                "interval": interval
            }
        except Exception as e:
            logger.error(f"Error getting event timeline: {e}")
            return {}
    
    def get_file_type_stats(self) -> Dict[str, Any]:
        """Get statistics by file type"""
        try:
            # Get all files
            files = self.persistence.get_all_files()
            
            # Group by file type
            file_types = defaultdict(list)
            for file in files:
                file_ext = os.path.splitext(file['path'])[1].lower()
                if not file_ext:
                    file_ext = "no_extension"
                else:
                    file_ext = file_ext[1:]  # Remove the dot
                
                file_types[file_ext].append(file)
            
            # Calculate stats for each file type
            stats = {}
            for file_ext, files in file_types.items():
                stats[file_ext] = {
                    "count": len(files),
                    "message_count": sum(file['message_count'] for file in files),
                    "avg_message_count": sum(file['message_count'] for file in files) / len(files),
                    "newest_file": max(files, key=lambda x: x['last_modified'])['path'],
                    "oldest_file": min(files, key=lambda x: x['created_at'])['path']
                }
            
            return stats
        except Exception as e:
            logger.error(f"Error getting file type stats: {e}")
            return {}

